## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **JPEG Compression (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **JPEG Compression (Switch).xml** — Info & Integration
- **JPEG Compression (Switch).fx** — Direct3D 9 source code
- **JPEG Compression (Switch).hlsl** — Direct3D 11 source code
- **JPEG Compression (Switch).fxc** — Direct3D 11 compiled
- **JPEG Compression (Switch).fxao** — OpenGL ES (Android) source code
- **JPEG Compression (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*