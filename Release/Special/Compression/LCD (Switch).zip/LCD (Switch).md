## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **LCD (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **LCD (Switch).xml** — Info & Integration
- **LCD (Switch).fx** — Direct3D 9 source code
- **LCD (Switch).hlsl** — Direct3D 11 source code
- **LCD (Switch).fxc** — Direct3D 11 compiled
- **LCD (Switch).fxao** — OpenGL ES (Android) source code
- **LCD (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*