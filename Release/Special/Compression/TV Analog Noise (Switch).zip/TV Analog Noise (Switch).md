## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **TV Analog Noise (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **TV Analog Noise (Switch).xml** — Info & Integration
- **TV Analog Noise (Switch).fx** — Direct3D 9 source code
- **TV Analog Noise (Switch).hlsl** — Direct3D 11 source code
- **TV Analog Noise (Switch).fxc** — Direct3D 11 compiled
- **TV Analog Noise (Switch).fxao** — OpenGL ES (Android) source code
- **TV Analog Noise (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*