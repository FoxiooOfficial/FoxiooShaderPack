## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Composite Video Compression (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Composite Video Compression (Texture).xml** — Info & Integration
- **Composite Video Compression (Texture).fx** — Direct3D 9 source code
- **Composite Video Compression (Texture).hlsl** — Direct3D 11 source code
- **Composite Video Compression (Texture).fxc** — Direct3D 11 compiled
- **Composite Video Compression (Texture).fxao** — OpenGL ES (Android) source code
- **Composite Video Compression (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*