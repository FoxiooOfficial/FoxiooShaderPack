## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Hologram (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Hologram (Switch).xml** — Info & Integration
- **Hologram (Switch).fx** — Direct3D 9 source code
- **Hologram (Switch).hlsl** — Direct3D 11 source code
- **Hologram (Switch).fxc** — Direct3D 11 compiled
- **Hologram (Switch).fxao** — OpenGL ES (Android) source code
- **Hologram (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*