## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **VHS (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **VHS (Background).xml** — Info & Integration
- **VHS (Background).fx** — Direct3D 9 source code
- **VHS (Background).hlsl** — Direct3D 11 source code
- **VHS (Background).fxc** — Direct3D 11 compiled
- **VHS (Background).fxao** — OpenGL ES (Android) source code
- **VHS (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Examples
- Trailer300.mfa

*The examples may require additional effects or extensions.*