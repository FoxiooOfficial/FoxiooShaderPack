## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **VHS (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **VHS (Texture).xml** — Info & Integration
- **VHS (Texture).fx** — Direct3D 9 source code
- **VHS (Texture).hlsl** — Direct3D 11 source code
- **VHS (Texture).fxc** — Direct3D 11 compiled
- **VHS (Texture).fxao** — OpenGL ES (Android) source code
- **VHS (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*