## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Freeze (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Freeze (Switch).xml** — Info & Integration
- **Freeze (Switch).fx** — Direct3D 9 source code
- **Freeze (Switch).hlsl** — Direct3D 11 source code
- **Freeze (Switch).fxc** — Direct3D 11 compiled
- **Freeze (Switch).fxao** — OpenGL ES (Android) source code
- **Freeze (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Textures
- Ice.png