## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Burn (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Burn (Switch).xml** — Info & Integration
- **Burn (Switch).fx** — Direct3D 9 source code
- **Burn (Switch).hlsl** — Direct3D 11 source code
- **Burn (Switch).fxc** — Direct3D 11 compiled
- **Burn (Switch).fxao** — OpenGL ES (Android) source code
- **Burn (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Textures
- Fire.png
- Mask.png