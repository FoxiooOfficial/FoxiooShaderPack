## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Geometry Dash Glass Blocks (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Geometry Dash Glass Blocks (Background).xml** — Info & Integration
- **Geometry Dash Glass Blocks (Background).fx** — Direct3D 9 source code
- **Geometry Dash Glass Blocks (Background).hlsl** — Direct3D 11 source code
- **Geometry Dash Glass Blocks (Background).fxc** — Direct3D 11 compiled
- **Geometry Dash Glass Blocks (Background).fxao** — OpenGL ES (Android) source code
- **Geometry Dash Glass Blocks (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Examples
- GlassBlocks.mfa

*The examples may require additional effects or extensions.*