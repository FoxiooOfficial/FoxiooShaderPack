## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Deltarune Vessel Background (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Deltarune Vessel Background (Switch).xml** — Info & Integration
- **Deltarune Vessel Background (Switch).fx** — Direct3D 9 source code
- **Deltarune Vessel Background (Switch).hlsl** — Direct3D 11 source code
- **Deltarune Vessel Background (Switch).fxc** — Direct3D 11 compiled
- **Deltarune Vessel Background (Switch).fxao** — OpenGL ES (Android) source code
- **Deltarune Vessel Background (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*