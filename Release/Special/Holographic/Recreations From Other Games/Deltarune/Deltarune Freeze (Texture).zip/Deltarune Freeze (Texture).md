## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Deltarune Freeze (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Deltarune Freeze (Texture).xml** — Info & Integration
- **Deltarune Freeze (Texture).fx** — Direct3D 9 source code
- **Deltarune Freeze (Texture).hlsl** — Direct3D 11 source code
- **Deltarune Freeze (Texture).fxc** — Direct3D 11 compiled
- **Deltarune Freeze (Texture).fxao** — OpenGL ES (Android) source code
- **Deltarune Freeze (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*