## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Deltarune Jevil Background Fight (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Deltarune Jevil Background Fight (Switch).xml** — Info & Integration
- **Deltarune Jevil Background Fight (Switch).fx** — Direct3D 9 source code
- **Deltarune Jevil Background Fight (Switch).hlsl** — Direct3D 11 source code
- **Deltarune Jevil Background Fight (Switch).fxc** — Direct3D 11 compiled
- **Deltarune Jevil Background Fight (Switch).fxao** — OpenGL ES (Android) source code
- **Deltarune Jevil Background Fight (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*