## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Deltarune Church Prophecy Panel (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Deltarune Church Prophecy Panel (Texture).xml** — Info & Integration
- **Deltarune Church Prophecy Panel (Texture).fx** — Direct3D 9 source code
- **Deltarune Church Prophecy Panel (Texture).hlsl** — Direct3D 11 source code
- **Deltarune Church Prophecy Panel (Texture).fxc** — Direct3D 11 compiled
- **Deltarune Church Prophecy Panel (Texture).fxao** — OpenGL ES (Android) source code
- **Deltarune Church Prophecy Panel (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Examples
- ChurchProphecyPanel.mfa

*The examples may require additional effects or extensions.*
## Textures
- DELTARUNE_DEPTH.png