## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Genshin Impact Natlan Outline (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Genshin Impact Natlan Outline (Background).xml** — Info & Integration
- **Genshin Impact Natlan Outline (Background).fx** — Direct3D 9 source code
- **Genshin Impact Natlan Outline (Background).hlsl** — Direct3D 11 source code
- **Genshin Impact Natlan Outline (Background).fxc** — Direct3D 11 compiled
- **Genshin Impact Natlan Outline (Background).fxao** — OpenGL ES (Android) source code
- **Genshin Impact Natlan Outline (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*