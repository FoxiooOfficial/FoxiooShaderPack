## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **End Portal (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **End Portal (Texture).xml** — Info & Integration
- **End Portal (Texture).fx** — Direct3D 9 source code
- **End Portal (Texture).hlsl** — Direct3D 11 source code
- **End Portal (Texture).fxc** — Direct3D 11 compiled
- **End Portal (Texture).fxao** — OpenGL ES (Android) source code
- **End Portal (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*