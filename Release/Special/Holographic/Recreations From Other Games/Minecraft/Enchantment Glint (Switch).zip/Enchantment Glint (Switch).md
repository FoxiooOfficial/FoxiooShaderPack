## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Enchantment Glint (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Enchantment Glint (Switch).xml** — Info & Integration
- **Enchantment Glint (Switch).fx** — Direct3D 9 source code
- **Enchantment Glint (Switch).hlsl** — Direct3D 11 source code
- **Enchantment Glint (Switch).fxc** — Direct3D 11 compiled
- **Enchantment Glint (Switch).fxao** — OpenGL ES (Android) source code
- **Enchantment Glint (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*