## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **PVZA Flower Cooldown (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **PVZA Flower Cooldown (Texture).xml** — Info & Integration
- **PVZA Flower Cooldown (Texture).fx** — Direct3D 9 source code
- **PVZA Flower Cooldown (Texture).hlsl** — Direct3D 11 source code
- **PVZA Flower Cooldown (Texture).fxc** — Direct3D 11 compiled
- **PVZA Flower Cooldown (Texture).fxao** — OpenGL ES (Android) source code
- **PVZA Flower Cooldown (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*