## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Segmented Liquid-Crystal Display (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Segmented Liquid-Crystal Display (Switch).xml** — Info & Integration
- **Segmented Liquid-Crystal Display (Switch).fx** — Direct3D 9 source code
- **Segmented Liquid-Crystal Display (Switch).hlsl** — Direct3D 11 source code
- **Segmented Liquid-Crystal Display (Switch).fxc** — Direct3D 11 compiled
- **Segmented Liquid-Crystal Display (Switch).fxao** — OpenGL ES (Android) source code
- **Segmented Liquid-Crystal Display (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*