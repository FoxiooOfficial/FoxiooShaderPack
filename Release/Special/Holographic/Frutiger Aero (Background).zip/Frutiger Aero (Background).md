## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Frutiger Aero (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Frutiger Aero (Background).xml** — Info & Integration
- **Frutiger Aero (Background).fx** — Direct3D 9 source code
- **Frutiger Aero (Background).hlsl** — Direct3D 11 source code
- **Frutiger Aero (Background).fxc** — Direct3D 11 compiled
- **Frutiger Aero (Background).fxao** — OpenGL ES (Android) source code
- **Frutiger Aero (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*