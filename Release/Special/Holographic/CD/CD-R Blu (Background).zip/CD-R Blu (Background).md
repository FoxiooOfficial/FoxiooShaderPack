## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **CD-R Blu (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **CD-R Blu (Background).xml** — Info & Integration
- **CD-R Blu (Background).fx** — Direct3D 9 source code
- **CD-R Blu (Background).hlsl** — Direct3D 11 source code
- **CD-R Blu (Background).fxc** — Direct3D 11 compiled
- **CD-R Blu (Background).fxao** — OpenGL ES (Android) source code
- **CD-R Blu (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*