## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **CD-R (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **CD-R (Background).xml** — Info & Integration
- **CD-R (Background).fx** — Direct3D 9 source code
- **CD-R (Background).hlsl** — Direct3D 11 source code
- **CD-R (Background).fxc** — Direct3D 11 compiled
- **CD-R (Background).fxao** — OpenGL ES (Android) source code
- **CD-R (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*