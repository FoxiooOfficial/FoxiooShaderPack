## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **RPB Foilage (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **RPB Foilage (Background).xml** — Info & Integration
- **RPB Foilage (Background).fx** — Direct3D 9 source code
- **RPB Foilage (Background).hlsl** — Direct3D 11 source code
- **RPB Foilage (Background).fxc** — Direct3D 11 compiled
- **RPB Foilage (Background).fxao** — OpenGL ES (Android) source code
- **RPB Foilage (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*