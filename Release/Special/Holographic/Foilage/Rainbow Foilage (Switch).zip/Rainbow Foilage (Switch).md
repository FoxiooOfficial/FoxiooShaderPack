## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Rainbow Foilage (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Rainbow Foilage (Switch).xml** — Info & Integration
- **Rainbow Foilage (Switch).fx** — Direct3D 9 source code
- **Rainbow Foilage (Switch).hlsl** — Direct3D 11 source code
- **Rainbow Foilage (Switch).fxc** — Direct3D 11 compiled
- **Rainbow Foilage (Switch).fxao** — OpenGL ES (Android) source code
- **Rainbow Foilage (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*