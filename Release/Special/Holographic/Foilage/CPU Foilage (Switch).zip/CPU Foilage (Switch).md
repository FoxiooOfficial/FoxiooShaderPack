## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **CPU Foilage (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **CPU Foilage (Switch).xml** — Info & Integration
- **CPU Foilage (Switch).fx** — Direct3D 9 source code
- **CPU Foilage (Switch).hlsl** — Direct3D 11 source code
- **CPU Foilage (Switch).fxc** — Direct3D 11 compiled
- **CPU Foilage (Switch).fxao** — OpenGL ES (Android) source code
- **CPU Foilage (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*