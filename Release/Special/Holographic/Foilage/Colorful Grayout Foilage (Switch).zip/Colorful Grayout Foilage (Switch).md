## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Colorful Grayout Foilage (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Colorful Grayout Foilage (Switch).xml** — Info & Integration
- **Colorful Grayout Foilage (Switch).fx** — Direct3D 9 source code
- **Colorful Grayout Foilage (Switch).hlsl** — Direct3D 11 source code
- **Colorful Grayout Foilage (Switch).fxc** — Direct3D 11 compiled
- **Colorful Grayout Foilage (Switch).fxao** — OpenGL ES (Android) source code
- **Colorful Grayout Foilage (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*