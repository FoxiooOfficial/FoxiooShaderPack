## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Aura (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Aura (Background).xml** — Info & Integration
- **Aura (Background).fx** — Direct3D 9 source code
- **Aura (Background).hlsl** — Direct3D 11 source code
- **Aura (Background).fxc** — Direct3D 11 compiled
- **Aura (Background).fxao** — OpenGL ES (Android) source code
- **Aura (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*