## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Void (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Void (Background).xml** — Info & Integration
- **Void (Background).fx** — Direct3D 9 source code
- **Void (Background).hlsl** — Direct3D 11 source code
- **Void (Background).fxc** — Direct3D 11 compiled
- **Void (Background).fxao** — OpenGL ES (Android) source code
- **Void (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Examples
- RoaringActiveMan.mfa

*The examples may require additional effects or extensions.*