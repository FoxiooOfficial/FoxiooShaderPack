## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Spectrogram (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Spectrogram (Switch).xml** — Info & Integration
- **Spectrogram (Switch).fx** — Direct3D 9 source code
- **Spectrogram (Switch).hlsl** — Direct3D 11 source code
- **Spectrogram (Switch).fxc** — Direct3D 11 compiled
- **Spectrogram (Switch).fxao** — OpenGL ES (Android) source code
- **Spectrogram (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*