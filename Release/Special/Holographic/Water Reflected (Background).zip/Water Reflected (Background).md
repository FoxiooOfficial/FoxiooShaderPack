## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Water Reflected (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Water Reflected (Background).xml** — Info & Integration
- **Water Reflected (Background).fx** — Direct3D 9 source code
- **Water Reflected (Background).hlsl** — Direct3D 11 source code
- **Water Reflected (Background).fxc** — Direct3D 11 compiled
- **Water Reflected (Background).fxao** — OpenGL ES (Android) source code
- **Water Reflected (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Examples
- ReflectionTest.mfa

*The examples may require additional effects or extensions.*
## Textures
- TEXTURENORMALPERLIN.png
- TEXTURENORMAL.png
- TEXTUREOVERLAY.png