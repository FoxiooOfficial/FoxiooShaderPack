## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Windows Aero (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Windows Aero (Background).xml** — Info & Integration
- **Windows Aero (Background).fx** — Direct3D 9 source code
- **Windows Aero (Background).hlsl** — Direct3D 11 source code
- **Windows Aero (Background).fxc** — Direct3D 11 compiled
- **Windows Aero (Background).fxao** — OpenGL ES (Android) source code
- **Windows Aero (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Examples
- Aero.mfa

*The examples may require additional effects or extensions.*