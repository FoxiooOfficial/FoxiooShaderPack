## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Windows Aero Tinted (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Windows Aero Tinted (Background).xml** — Info & Integration
- **Windows Aero Tinted (Background).fx** — Direct3D 9 source code
- **Windows Aero Tinted (Background).hlsl** — Direct3D 11 source code
- **Windows Aero Tinted (Background).fxc** — Direct3D 11 compiled
- **Windows Aero Tinted (Background).fxao** — OpenGL ES (Android) source code
- **Windows Aero Tinted (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*