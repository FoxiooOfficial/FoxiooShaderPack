## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Windows Aero Clean (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Windows Aero Clean (Background).xml** — Info & Integration
- **Windows Aero Clean (Background).fx** — Direct3D 9 source code
- **Windows Aero Clean (Background).hlsl** — Direct3D 11 source code
- **Windows Aero Clean (Background).fxc** — Direct3D 11 compiled
- **Windows Aero Clean (Background).fxao** — OpenGL ES (Android) source code
- **Windows Aero Clean (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*