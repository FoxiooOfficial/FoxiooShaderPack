## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Liquid Glass Blurry (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Liquid Glass Blurry (Background).xml** — Info & Integration
- **Liquid Glass Blurry (Background).fx** — Direct3D 9 source code
- **Liquid Glass Blurry (Background).hlsl** — Direct3D 11 source code
- **Liquid Glass Blurry (Background).fxc** — Direct3D 11 compiled
- **Liquid Glass Blurry (Background).fxao** — OpenGL ES (Android) source code
- **Liquid Glass Blurry (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*