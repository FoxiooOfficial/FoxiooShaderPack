## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Liquid Glass (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Liquid Glass (Background).xml** — Info & Integration
- **Liquid Glass (Background).fx** — Direct3D 9 source code
- **Liquid Glass (Background).hlsl** — Direct3D 11 source code
- **Liquid Glass (Background).fxc** — Direct3D 11 compiled
- **Liquid Glass (Background).fxao** — OpenGL ES (Android) source code
- **Liquid Glass (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Examples
- LiquidGlass.mfa

*The examples may require additional effects or extensions.*