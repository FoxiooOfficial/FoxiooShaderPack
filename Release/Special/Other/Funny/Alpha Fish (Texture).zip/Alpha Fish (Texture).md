## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Alpha Fish (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Alpha Fish (Texture).xml** — Info & Integration
- **Alpha Fish (Texture).fx** — Direct3D 9 source code
- **Alpha Fish (Texture).hlsl** — Direct3D 11 source code
- **Alpha Fish (Texture).fxc** — Direct3D 11 compiled
- **Alpha Fish (Texture).fxao** — OpenGL ES (Android) source code
- **Alpha Fish (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*