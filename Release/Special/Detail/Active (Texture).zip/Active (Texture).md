## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Active (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Active (Texture).xml** — Info & Integration
- **Active (Texture).fx** — Direct3D 9 source code
- **Active (Texture).hlsl** — Direct3D 11 source code
- **Active (Texture).fxc** — Direct3D 11 compiled
- **Active (Texture).fxao** — OpenGL ES (Android) source code
- **Active (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*