## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Sharpness (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Sharpness (Switch).xml** — Info & Integration
- **Sharpness (Switch).fx** — Direct3D 9 source code
- **Sharpness (Switch).hlsl** — Direct3D 11 source code
- **Sharpness (Switch).fxc** — Direct3D 11 compiled
- **Sharpness (Switch).fxao** — OpenGL ES (Android) source code
- **Sharpness (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*