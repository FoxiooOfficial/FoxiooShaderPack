## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Bevel Smooth (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Bevel Smooth (Texture).xml** — Info & Integration
- **Bevel Smooth (Texture).fx** — Direct3D 9 source code
- **Bevel Smooth (Texture).hlsl** — Direct3D 11 source code
- **Bevel Smooth (Texture).fxc** — Direct3D 11 compiled
- **Bevel Smooth (Texture).fxao** — OpenGL ES (Android) source code
- **Bevel Smooth (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*