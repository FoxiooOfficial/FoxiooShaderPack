## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Normal Map (Switch) [Direct3D].premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Normal Map (Switch) [Direct3D].xml** — Info & Integration
- **Normal Map (Switch) [Direct3D].fx** — Direct3D 9 source code
- **Normal Map (Switch) [Direct3D].hlsl** — Direct3D 11 source code
- **Normal Map (Switch) [Direct3D].fxc** — Direct3D 11 compiled
- **Normal Map (Switch) [Direct3D].fxao** — OpenGL ES (Android) source code
- **Normal Map (Switch) [Direct3D].fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*