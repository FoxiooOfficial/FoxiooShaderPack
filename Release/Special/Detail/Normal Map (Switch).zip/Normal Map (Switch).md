## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Normal Map (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Normal Map (Switch).xml** — Info & Integration
- **Normal Map (Switch).fx** — Direct3D 9 source code
- **Normal Map (Switch).hlsl** — Direct3D 11 source code
- **Normal Map (Switch).fxc** — Direct3D 11 compiled
- **Normal Map (Switch).fxao** — OpenGL ES (Android) source code
- **Normal Map (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*