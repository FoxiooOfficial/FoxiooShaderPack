## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Emboss (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Emboss (Switch).xml** — Info & Integration
- **Emboss (Switch).fx** — Direct3D 9 source code
- **Emboss (Switch).hlsl** — Direct3D 11 source code
- **Emboss (Switch).fxc** — Direct3D 11 compiled
- **Emboss (Switch).fxao** — OpenGL ES (Android) source code
- **Emboss (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*