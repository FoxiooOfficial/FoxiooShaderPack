## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Vector Gradient Bloom (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Vector Gradient Bloom (Switch).xml** — Info & Integration
- **Vector Gradient Bloom (Switch).fx** — Direct3D 9 source code
- **Vector Gradient Bloom (Switch).hlsl** — Direct3D 11 source code
- **Vector Gradient Bloom (Switch).fxc** — Direct3D 11 compiled
- **Vector Gradient Bloom (Switch).fxao** — OpenGL ES (Android) source code
- **Vector Gradient Bloom (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*