## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Better Bloom (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Better Bloom (Background).xml** — Info & Integration
- **Better Bloom (Background).fx** — Direct3D 9 source code
- **Better Bloom (Background).hlsl** — Direct3D 11 source code
- **Better Bloom (Background).fxc** — Direct3D 11 compiled
- **Better Bloom (Background).fxao** — OpenGL ES (Android) source code
- **Better Bloom (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*