## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Animeish (Switch) [Legacy].premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Animeish (Switch) [Legacy].xml** — Info & Integration
- **Animeish (Switch) [Legacy].fx** — Direct3D 9 source code
- **Animeish (Switch) [Legacy].hlsl** — Direct3D 11 source code
- **Animeish (Switch) [Legacy].fxc** — Direct3D 11 compiled
- **Animeish (Switch) [Legacy].fxao** — OpenGL ES (Android) source code
- **Animeish (Switch) [Legacy].fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*