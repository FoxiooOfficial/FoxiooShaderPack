## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Mangaish (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Mangaish (Switch).xml** — Info & Integration
- **Mangaish (Switch).fx** — Direct3D 9 source code
- **Mangaish (Switch).hlsl** — Direct3D 11 source code
- **Mangaish (Switch).fxc** — Direct3D 11 compiled
- **Mangaish (Switch).fxao** — OpenGL ES (Android) source code
- **Mangaish (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*