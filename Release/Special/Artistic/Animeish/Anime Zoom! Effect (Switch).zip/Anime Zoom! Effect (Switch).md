## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Anime Zoom! Effect (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Anime Zoom! Effect (Switch).xml** — Info & Integration
- **Anime Zoom! Effect (Switch).fx** — Direct3D 9 source code
- **Anime Zoom! Effect (Switch).hlsl** — Direct3D 11 source code
- **Anime Zoom! Effect (Switch).fxc** — Direct3D 11 compiled
- **Anime Zoom! Effect (Switch).fxao** — OpenGL ES (Android) source code
- **Anime Zoom! Effect (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*