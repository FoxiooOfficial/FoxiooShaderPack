## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Genshin Shader 3.0 Skin (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Genshin Shader 3.0 Skin (Switch).xml** — Info & Integration
- **Genshin Shader 3.0 Skin (Switch).fx** — Direct3D 9 source code
- **Genshin Shader 3.0 Skin (Switch).hlsl** — Direct3D 11 source code
- **Genshin Shader 3.0 Skin (Switch).fxc** — Direct3D 11 compiled
- **Genshin Shader 3.0 Skin (Switch).fxao** — OpenGL ES (Android) source code
- **Genshin Shader 3.0 Skin (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Textures
- RimLightFace.png