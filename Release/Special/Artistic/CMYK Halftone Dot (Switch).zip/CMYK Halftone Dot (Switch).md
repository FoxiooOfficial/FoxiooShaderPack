## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **CMYK Halftone Dot (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **CMYK Halftone Dot (Switch).xml** — Info & Integration
- **CMYK Halftone Dot (Switch).fx** — Direct3D 9 source code
- **CMYK Halftone Dot (Switch).hlsl** — Direct3D 11 source code
- **CMYK Halftone Dot (Switch).fxc** — Direct3D 11 compiled
- **CMYK Halftone Dot (Switch).fxao** — OpenGL ES (Android) source code
- **CMYK Halftone Dot (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*