## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Screen Space Reflection (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Screen Space Reflection (Texture).xml** — Info & Integration
- **Screen Space Reflection (Texture).fx** — Direct3D 9 source code
- **Screen Space Reflection (Texture).hlsl** — Direct3D 11 source code
- **Screen Space Reflection (Texture).fxc** — Direct3D 11 compiled
- **Screen Space Reflection (Texture).fxao** — OpenGL ES (Android) source code
- **Screen Space Reflection (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Examples
- ScreenSpaceReflection.mfa

*The examples may require additional effects or extensions.*