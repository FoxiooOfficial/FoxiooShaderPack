## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Vector Gradient Blur (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Vector Gradient Blur (Switch).xml** — Info & Integration
- **Vector Gradient Blur (Switch).fx** — Direct3D 9 source code
- **Vector Gradient Blur (Switch).hlsl** — Direct3D 11 source code
- **Vector Gradient Blur (Switch).fxc** — Direct3D 11 compiled
- **Vector Gradient Blur (Switch).fxao** — OpenGL ES (Android) source code
- **Vector Gradient Blur (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*