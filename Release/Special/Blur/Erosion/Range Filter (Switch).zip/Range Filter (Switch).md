## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Range Filter (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Range Filter (Switch).xml** — Info & Integration
- **Range Filter (Switch).fx** — Direct3D 9 source code
- **Range Filter (Switch).hlsl** — Direct3D 11 source code
- **Range Filter (Switch).fxc** — Direct3D 11 compiled
- **Range Filter (Switch).fxao** — OpenGL ES (Android) source code
- **Range Filter (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*