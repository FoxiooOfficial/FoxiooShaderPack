## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Minimum Filter (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Minimum Filter (Switch).xml** — Info & Integration
- **Minimum Filter (Switch).fx** — Direct3D 9 source code
- **Minimum Filter (Switch).hlsl** — Direct3D 11 source code
- **Minimum Filter (Switch).fxc** — Direct3D 11 compiled
- **Minimum Filter (Switch).fxao** — OpenGL ES (Android) source code
- **Minimum Filter (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*