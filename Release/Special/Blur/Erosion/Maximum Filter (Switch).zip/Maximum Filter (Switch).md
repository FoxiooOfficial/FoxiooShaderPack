## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Maximum Filter (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Maximum Filter (Switch).xml** — Info & Integration
- **Maximum Filter (Switch).fx** — Direct3D 9 source code
- **Maximum Filter (Switch).hlsl** — Direct3D 11 source code
- **Maximum Filter (Switch).fxc** — Direct3D 11 compiled
- **Maximum Filter (Switch).fxao** — OpenGL ES (Android) source code
- **Maximum Filter (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*