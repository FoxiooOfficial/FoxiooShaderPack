## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Midpoint Filter (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Midpoint Filter (Switch).xml** — Info & Integration
- **Midpoint Filter (Switch).fx** — Direct3D 9 source code
- **Midpoint Filter (Switch).hlsl** — Direct3D 11 source code
- **Midpoint Filter (Switch).fxc** — Direct3D 11 compiled
- **Midpoint Filter (Switch).fxao** — OpenGL ES (Android) source code
- **Midpoint Filter (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*