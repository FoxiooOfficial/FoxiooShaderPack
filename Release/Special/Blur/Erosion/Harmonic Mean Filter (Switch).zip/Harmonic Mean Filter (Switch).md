## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Harmonic Mean Filter (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Harmonic Mean Filter (Switch).xml** — Info & Integration
- **Harmonic Mean Filter (Switch).fx** — Direct3D 9 source code
- **Harmonic Mean Filter (Switch).hlsl** — Direct3D 11 source code
- **Harmonic Mean Filter (Switch).fxc** — Direct3D 11 compiled
- **Harmonic Mean Filter (Switch).fxao** — OpenGL ES (Android) source code
- **Harmonic Mean Filter (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*