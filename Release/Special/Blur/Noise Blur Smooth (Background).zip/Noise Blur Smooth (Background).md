## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Noise Blur Smooth (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Noise Blur Smooth (Background).xml** — Info & Integration
- **Noise Blur Smooth (Background).fx** — Direct3D 9 source code
- **Noise Blur Smooth (Background).hlsl** — Direct3D 11 source code
- **Noise Blur Smooth (Background).fxc** — Direct3D 11 compiled
- **Noise Blur Smooth (Background).fxao** — OpenGL ES (Android) source code
- **Noise Blur Smooth (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*