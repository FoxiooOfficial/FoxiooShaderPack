## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **ClearType (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **ClearType (Switch).xml** — Info & Integration
- **ClearType (Switch).fx** — Direct3D 9 source code
- **ClearType (Switch).hlsl** — Direct3D 11 source code
- **ClearType (Switch).fxc** — Direct3D 11 compiled
- **ClearType (Switch).fxao** — OpenGL ES (Android) source code
- **ClearType (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*