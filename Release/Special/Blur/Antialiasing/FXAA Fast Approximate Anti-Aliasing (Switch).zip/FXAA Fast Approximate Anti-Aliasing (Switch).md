## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **FXAA Fast Approximate Anti-Aliasing (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **FXAA Fast Approximate Anti-Aliasing (Switch).xml** — Info & Integration
- **FXAA Fast Approximate Anti-Aliasing (Switch).fx** — Direct3D 9 source code
- **FXAA Fast Approximate Anti-Aliasing (Switch).hlsl** — Direct3D 11 source code
- **FXAA Fast Approximate Anti-Aliasing (Switch).fxc** — Direct3D 11 compiled
- **FXAA Fast Approximate Anti-Aliasing (Switch).fxao** — OpenGL ES (Android) source code
- **FXAA Fast Approximate Anti-Aliasing (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*