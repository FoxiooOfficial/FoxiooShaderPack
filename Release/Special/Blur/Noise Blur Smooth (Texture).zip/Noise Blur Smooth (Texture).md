## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Noise Blur Smooth (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Noise Blur Smooth (Texture).xml** — Info & Integration
- **Noise Blur Smooth (Texture).fx** — Direct3D 9 source code
- **Noise Blur Smooth (Texture).hlsl** — Direct3D 11 source code
- **Noise Blur Smooth (Texture).fxc** — Direct3D 11 compiled
- **Noise Blur Smooth (Texture).fxao** — OpenGL ES (Android) source code
- **Noise Blur Smooth (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*