## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **EGA 64-Color (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **EGA 64-Color (Switch).xml** — Info & Integration
- **EGA 64-Color (Switch).fx** — Direct3D 9 source code
- **EGA 64-Color (Switch).hlsl** — Direct3D 11 source code
- **EGA 64-Color (Switch).fxc** — Direct3D 11 compiled
- **EGA 64-Color (Switch).fxao** — OpenGL ES (Android) source code
- **EGA 64-Color (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*