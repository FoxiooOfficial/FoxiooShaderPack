## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **MS Paint (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **MS Paint (Switch).xml** — Info & Integration
- **MS Paint (Switch).fx** — Direct3D 9 source code
- **MS Paint (Switch).hlsl** — Direct3D 11 source code
- **MS Paint (Switch).fxc** — Direct3D 11 compiled
- **MS Paint (Switch).fxao** — OpenGL ES (Android) source code
- **MS Paint (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*