## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **CGA 4-Color_1 (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **CGA 4-Color_1 (Switch).xml** — Info & Integration
- **CGA 4-Color_1 (Switch).fx** — Direct3D 9 source code
- **CGA 4-Color_1 (Switch).hlsl** — Direct3D 11 source code
- **CGA 4-Color_1 (Switch).fxc** — Direct3D 11 compiled
- **CGA 4-Color_1 (Switch).fxao** — OpenGL ES (Android) source code
- **CGA 4-Color_1 (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*