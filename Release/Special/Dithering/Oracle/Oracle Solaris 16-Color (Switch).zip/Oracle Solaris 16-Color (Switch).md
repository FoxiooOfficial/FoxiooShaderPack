## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Oracle Solaris 16-Color (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Oracle Solaris 16-Color (Switch).xml** — Info & Integration
- **Oracle Solaris 16-Color (Switch).fx** — Direct3D 9 source code
- **Oracle Solaris 16-Color (Switch).hlsl** — Direct3D 11 source code
- **Oracle Solaris 16-Color (Switch).fxc** — Direct3D 11 compiled
- **Oracle Solaris 16-Color (Switch).fxao** — OpenGL ES (Android) source code
- **Oracle Solaris 16-Color (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*