## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Game Boy Pocket 4-Color (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Game Boy Pocket 4-Color (Switch).xml** — Info & Integration
- **Game Boy Pocket 4-Color (Switch).fx** — Direct3D 9 source code
- **Game Boy Pocket 4-Color (Switch).hlsl** — Direct3D 11 source code
- **Game Boy Pocket 4-Color (Switch).fxc** — Direct3D 11 compiled
- **Game Boy Pocket 4-Color (Switch).fxao** — OpenGL ES (Android) source code
- **Game Boy Pocket 4-Color (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*