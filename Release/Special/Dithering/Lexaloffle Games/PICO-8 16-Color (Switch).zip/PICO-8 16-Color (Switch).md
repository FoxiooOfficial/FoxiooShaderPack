## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **PICO-8 16-Color (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **PICO-8 16-Color (Switch).xml** — Info & Integration
- **PICO-8 16-Color (Switch).fx** — Direct3D 9 source code
- **PICO-8 16-Color (Switch).hlsl** — Direct3D 11 source code
- **PICO-8 16-Color (Switch).fxc** — Direct3D 11 compiled
- **PICO-8 16-Color (Switch).fxao** — OpenGL ES (Android) source code
- **PICO-8 16-Color (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*