## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **PICO-8 16-ColorHP (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **PICO-8 16-ColorHP (Switch).xml** — Info & Integration
- **PICO-8 16-ColorHP (Switch).fx** — Direct3D 9 source code
- **PICO-8 16-ColorHP (Switch).hlsl** — Direct3D 11 source code
- **PICO-8 16-ColorHP (Switch).fxc** — Direct3D 11 compiled
- **PICO-8 16-ColorHP (Switch).fxao** — OpenGL ES (Android) source code
- **PICO-8 16-ColorHP (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*