## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Kaleidoscope (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Kaleidoscope (Switch).xml** — Info & Integration
- **Kaleidoscope (Switch).fx** — Direct3D 9 source code
- **Kaleidoscope (Switch).hlsl** — Direct3D 11 source code
- **Kaleidoscope (Switch).fxc** — Direct3D 11 compiled
- **Kaleidoscope (Switch).fxao** — OpenGL ES (Android) source code
- **Kaleidoscope (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*