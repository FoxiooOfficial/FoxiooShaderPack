## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Flip (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Flip (Switch).xml** — Info & Integration
- **Flip (Switch).fx** — Direct3D 9 source code
- **Flip (Switch).hlsl** — Direct3D 11 source code
- **Flip (Switch).fxc** — Direct3D 11 compiled
- **Flip (Switch).fxao** — OpenGL ES (Android) source code
- **Flip (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*