## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Shear (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Shear (Switch).xml** — Info & Integration
- **Shear (Switch).fx** — Direct3D 9 source code
- **Shear (Switch).hlsl** — Direct3D 11 source code
- **Shear (Switch).fxc** — Direct3D 11 compiled
- **Shear (Switch).fxao** — OpenGL ES (Android) source code
- **Shear (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*