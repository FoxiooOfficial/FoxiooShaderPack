## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Quad Mask (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Quad Mask (Texture).xml** — Info & Integration
- **Quad Mask (Texture).fx** — Direct3D 9 source code
- **Quad Mask (Texture).hlsl** — Direct3D 11 source code
- **Quad Mask (Texture).fxc** — Direct3D 11 compiled
- **Quad Mask (Texture).fxao** — OpenGL ES (Android) source code
- **Quad Mask (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*