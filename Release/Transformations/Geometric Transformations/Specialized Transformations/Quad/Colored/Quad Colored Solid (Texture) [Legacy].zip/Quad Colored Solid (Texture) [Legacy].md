## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Quad Colored Solid (Texture) [Legacy].premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Quad Colored Solid (Texture) [Legacy].xml** — Info & Integration
- **Quad Colored Solid (Texture) [Legacy].fx** — Direct3D 9 source code
- **Quad Colored Solid (Texture) [Legacy].hlsl** — Direct3D 11 source code
- **Quad Colored Solid (Texture) [Legacy].fxc** — Direct3D 11 compiled
- **Quad Colored Solid (Texture) [Legacy].fxao** — OpenGL ES (Android) source code
- **Quad Colored Solid (Texture) [Legacy].fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*