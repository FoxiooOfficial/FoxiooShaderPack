## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Quad With Reflections (Background) [Legacy].premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Quad With Reflections (Background) [Legacy].xml** — Info & Integration
- **Quad With Reflections (Background) [Legacy].fx** — Direct3D 9 source code
- **Quad With Reflections (Background) [Legacy].hlsl** — Direct3D 11 source code
- **Quad With Reflections (Background) [Legacy].fxc** — Direct3D 11 compiled
- **Quad With Reflections (Background) [Legacy].fxao** — OpenGL ES (Android) source code
- **Quad With Reflections (Background) [Legacy].fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*