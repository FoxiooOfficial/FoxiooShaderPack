## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Quad With Reflections (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Quad With Reflections (Background).xml** — Info & Integration
- **Quad With Reflections (Background).fx** — Direct3D 9 source code
- **Quad With Reflections (Background).hlsl** — Direct3D 11 source code
- **Quad With Reflections (Background).fxc** — Direct3D 11 compiled
- **Quad With Reflections (Background).fxao** — OpenGL ES (Android) source code
- **Quad With Reflections (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*