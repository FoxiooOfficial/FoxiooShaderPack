## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Quad PSX (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Quad PSX (Texture).xml** — Info & Integration
- **Quad PSX (Texture).fx** — Direct3D 9 source code
- **Quad PSX (Texture).hlsl** — Direct3D 11 source code
- **Quad PSX (Texture).fxc** — Direct3D 11 compiled
- **Quad PSX (Texture).fxao** — OpenGL ES (Android) source code
- **Quad PSX (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*