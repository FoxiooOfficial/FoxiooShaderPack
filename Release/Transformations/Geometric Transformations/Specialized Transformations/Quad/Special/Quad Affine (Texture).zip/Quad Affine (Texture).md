## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Quad Affine (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Quad Affine (Texture).xml** — Info & Integration
- **Quad Affine (Texture).fx** — Direct3D 9 source code
- **Quad Affine (Texture).hlsl** — Direct3D 11 source code
- **Quad Affine (Texture).fxc** — Direct3D 11 compiled
- **Quad Affine (Texture).fxao** — OpenGL ES (Android) source code
- **Quad Affine (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*