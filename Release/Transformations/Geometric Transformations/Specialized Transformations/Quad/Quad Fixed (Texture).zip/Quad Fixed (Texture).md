## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Quad Fixed (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Quad Fixed (Texture).xml** — Info & Integration
- **Quad Fixed (Texture).fx** — Direct3D 9 source code
- **Quad Fixed (Texture).hlsl** — Direct3D 11 source code
- **Quad Fixed (Texture).fxc** — Direct3D 11 compiled
- **Quad Fixed (Texture).fxao** — OpenGL ES (Android) source code
- **Quad Fixed (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*