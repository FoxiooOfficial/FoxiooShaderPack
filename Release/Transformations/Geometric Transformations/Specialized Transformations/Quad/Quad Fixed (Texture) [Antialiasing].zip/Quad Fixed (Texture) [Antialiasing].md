## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Quad Fixed (Texture) [Antialiasing].premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Quad Fixed (Texture) [Antialiasing].xml** — Info & Integration
- **Quad Fixed (Texture) [Antialiasing].fx** — Direct3D 9 source code
- **Quad Fixed (Texture) [Antialiasing].hlsl** — Direct3D 11 source code
- **Quad Fixed (Texture) [Antialiasing].fxc** — Direct3D 11 compiled
- **Quad Fixed (Texture) [Antialiasing].fxao** — OpenGL ES (Android) source code
- **Quad Fixed (Texture) [Antialiasing].fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*