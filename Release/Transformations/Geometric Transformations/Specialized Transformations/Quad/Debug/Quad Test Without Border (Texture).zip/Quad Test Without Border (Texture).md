## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Quad Test Without Border (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Quad Test Without Border (Texture).xml** — Info & Integration
- **Quad Test Without Border (Texture).fx** — Direct3D 9 source code
- **Quad Test Without Border (Texture).hlsl** — Direct3D 11 source code
- **Quad Test Without Border (Texture).fxc** — Direct3D 11 compiled
- **Quad Test Without Border (Texture).fxao** — OpenGL ES (Android) source code
- **Quad Test Without Border (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*