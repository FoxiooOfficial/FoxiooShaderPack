## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Quad Wire-Frame (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Quad Wire-Frame (Texture).xml** — Info & Integration
- **Quad Wire-Frame (Texture).fx** — Direct3D 9 source code
- **Quad Wire-Frame (Texture).hlsl** — Direct3D 11 source code
- **Quad Wire-Frame (Texture).fxc** — Direct3D 11 compiled
- **Quad Wire-Frame (Texture).fxao** — OpenGL ES (Android) source code
- **Quad Wire-Frame (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*