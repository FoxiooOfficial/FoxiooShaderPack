## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **T7Sprite (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **T7Sprite (Texture).xml** — Info & Integration
- **T7Sprite (Texture).fx** — Direct3D 9 source code
- **T7Sprite (Texture).hlsl** — Direct3D 11 source code
- **T7Sprite (Texture).fxc** — Direct3D 11 compiled
- **T7Sprite (Texture).fxao** — OpenGL ES (Android) source code
- **T7Sprite (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*