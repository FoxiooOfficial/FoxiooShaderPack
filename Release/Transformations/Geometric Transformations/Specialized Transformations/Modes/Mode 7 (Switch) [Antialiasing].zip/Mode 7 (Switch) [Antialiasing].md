## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Mode 7 (Switch) [Antialiasing].premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Mode 7 (Switch) [Antialiasing].xml** — Info & Integration
- **Mode 7 (Switch) [Antialiasing].fx** — Direct3D 9 source code
- **Mode 7 (Switch) [Antialiasing].hlsl** — Direct3D 11 source code
- **Mode 7 (Switch) [Antialiasing].fxc** — Direct3D 11 compiled
- **Mode 7 (Switch) [Antialiasing].fxao** — OpenGL ES (Android) source code
- **Mode 7 (Switch) [Antialiasing].fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*