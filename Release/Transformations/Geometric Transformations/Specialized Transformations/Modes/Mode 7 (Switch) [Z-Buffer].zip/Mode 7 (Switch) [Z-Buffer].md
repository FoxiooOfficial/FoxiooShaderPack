## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Mode 7 (Switch) [Z-Buffer].premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Mode 7 (Switch) [Z-Buffer].xml** — Info & Integration
- **Mode 7 (Switch) [Z-Buffer].fx** — Direct3D 9 source code
- **Mode 7 (Switch) [Z-Buffer].hlsl** — Direct3D 11 source code
- **Mode 7 (Switch) [Z-Buffer].fxc** — Direct3D 11 compiled
- **Mode 7 (Switch) [Z-Buffer].fxao** — OpenGL ES (Android) source code
- **Mode 7 (Switch) [Z-Buffer].fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*