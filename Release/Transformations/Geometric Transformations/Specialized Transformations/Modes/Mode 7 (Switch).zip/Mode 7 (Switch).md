## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Mode 7 (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Mode 7 (Switch).xml** — Info & Integration
- **Mode 7 (Switch).fx** — Direct3D 9 source code
- **Mode 7 (Switch).hlsl** — Direct3D 11 source code
- **Mode 7 (Switch).fxc** — Direct3D 11 compiled
- **Mode 7 (Switch).fxao** — OpenGL ES (Android) source code
- **Mode 7 (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*