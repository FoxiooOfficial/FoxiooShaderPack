## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Polygon Mask Overwrite (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Polygon Mask Overwrite (Texture).xml** — Info & Integration
- **Polygon Mask Overwrite (Texture).fx** — Direct3D 9 source code
- **Polygon Mask Overwrite (Texture).hlsl** — Direct3D 11 source code
- **Polygon Mask Overwrite (Texture).fxc** — Direct3D 11 compiled
- **Polygon Mask Overwrite (Texture).fxao** — OpenGL ES (Android) source code
- **Polygon Mask Overwrite (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*