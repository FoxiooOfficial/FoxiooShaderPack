## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Polygon Inverted Mask (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Polygon Inverted Mask (Texture).xml** — Info & Integration
- **Polygon Inverted Mask (Texture).fx** — Direct3D 9 source code
- **Polygon Inverted Mask (Texture).hlsl** — Direct3D 11 source code
- **Polygon Inverted Mask (Texture).fxc** — Direct3D 11 compiled
- **Polygon Inverted Mask (Texture).fxao** — OpenGL ES (Android) source code
- **Polygon Inverted Mask (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*