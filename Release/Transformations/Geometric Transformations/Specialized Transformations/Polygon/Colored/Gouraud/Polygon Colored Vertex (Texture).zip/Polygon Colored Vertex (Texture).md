## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Polygon Colored Vertex (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Polygon Colored Vertex (Texture).xml** — Info & Integration
- **Polygon Colored Vertex (Texture).fx** — Direct3D 9 source code
- **Polygon Colored Vertex (Texture).hlsl** — Direct3D 11 source code
- **Polygon Colored Vertex (Texture).fxc** — Direct3D 11 compiled
- **Polygon Colored Vertex (Texture).fxao** — OpenGL ES (Android) source code
- **Polygon Colored Vertex (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*