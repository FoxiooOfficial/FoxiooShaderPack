## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Polygon Blend Mul (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Polygon Blend Mul (Background).xml** — Info & Integration
- **Polygon Blend Mul (Background).fx** — Direct3D 9 source code
- **Polygon Blend Mul (Background).hlsl** — Direct3D 11 source code
- **Polygon Blend Mul (Background).fxc** — Direct3D 11 compiled
- **Polygon Blend Mul (Background).fxao** — OpenGL ES (Android) source code
- **Polygon Blend Mul (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*