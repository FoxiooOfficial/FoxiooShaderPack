## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Polygon Blend Sub (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Polygon Blend Sub (Background).xml** — Info & Integration
- **Polygon Blend Sub (Background).fx** — Direct3D 9 source code
- **Polygon Blend Sub (Background).hlsl** — Direct3D 11 source code
- **Polygon Blend Sub (Background).fxc** — Direct3D 11 compiled
- **Polygon Blend Sub (Background).fxao** — OpenGL ES (Android) source code
- **Polygon Blend Sub (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*