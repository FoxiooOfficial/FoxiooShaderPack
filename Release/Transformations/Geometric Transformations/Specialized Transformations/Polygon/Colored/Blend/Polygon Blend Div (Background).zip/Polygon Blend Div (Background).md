## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Polygon Blend Div (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Polygon Blend Div (Background).xml** — Info & Integration
- **Polygon Blend Div (Background).fx** — Direct3D 9 source code
- **Polygon Blend Div (Background).hlsl** — Direct3D 11 source code
- **Polygon Blend Div (Background).fxc** — Direct3D 11 compiled
- **Polygon Blend Div (Background).fxao** — OpenGL ES (Android) source code
- **Polygon Blend Div (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*