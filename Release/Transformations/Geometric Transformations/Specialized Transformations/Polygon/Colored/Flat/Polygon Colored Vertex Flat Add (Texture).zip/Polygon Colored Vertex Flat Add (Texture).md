## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Polygon Colored Vertex Flat Add (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Polygon Colored Vertex Flat Add (Texture).xml** — Info & Integration
- **Polygon Colored Vertex Flat Add (Texture).fx** — Direct3D 9 source code
- **Polygon Colored Vertex Flat Add (Texture).hlsl** — Direct3D 11 source code
- **Polygon Colored Vertex Flat Add (Texture).fxc** — Direct3D 11 compiled
- **Polygon Colored Vertex Flat Add (Texture).fxao** — OpenGL ES (Android) source code
- **Polygon Colored Vertex Flat Add (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*