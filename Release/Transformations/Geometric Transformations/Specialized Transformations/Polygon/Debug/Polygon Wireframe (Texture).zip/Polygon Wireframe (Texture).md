## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Polygon Wireframe (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Polygon Wireframe (Texture).xml** — Info & Integration
- **Polygon Wireframe (Texture).fx** — Direct3D 9 source code
- **Polygon Wireframe (Texture).hlsl** — Direct3D 11 source code
- **Polygon Wireframe (Texture).fxc** — Direct3D 11 compiled
- **Polygon Wireframe (Texture).fxao** — OpenGL ES (Android) source code
- **Polygon Wireframe (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*