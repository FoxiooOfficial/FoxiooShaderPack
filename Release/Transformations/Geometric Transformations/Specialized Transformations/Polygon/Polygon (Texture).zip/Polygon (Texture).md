## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Polygon (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Polygon (Texture).xml** — Info & Integration
- **Polygon (Texture).fx** — Direct3D 9 source code
- **Polygon (Texture).hlsl** — Direct3D 11 source code
- **Polygon (Texture).fxc** — Direct3D 11 compiled
- **Polygon (Texture).fxao** — OpenGL ES (Android) source code
- **Polygon (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*