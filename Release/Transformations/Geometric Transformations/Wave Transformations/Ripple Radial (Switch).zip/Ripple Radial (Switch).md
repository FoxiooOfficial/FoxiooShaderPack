## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Ripple Radial (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Ripple Radial (Switch).xml** — Info & Integration
- **Ripple Radial (Switch).fx** — Direct3D 9 source code
- **Ripple Radial (Switch).hlsl** — Direct3D 11 source code
- **Ripple Radial (Switch).fxc** — Direct3D 11 compiled
- **Ripple Radial (Switch).fxao** — OpenGL ES (Android) source code
- **Ripple Radial (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*