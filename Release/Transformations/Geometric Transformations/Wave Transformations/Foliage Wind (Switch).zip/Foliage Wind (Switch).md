## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Foliage Wind (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Foliage Wind (Switch).xml** — Info & Integration
- **Foliage Wind (Switch).fx** — Direct3D 9 source code
- **Foliage Wind (Switch).hlsl** — Direct3D 11 source code
- **Foliage Wind (Switch).fxc** — Direct3D 11 compiled
- **Foliage Wind (Switch).fxao** — OpenGL ES (Android) source code
- **Foliage Wind (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*