## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Sinus Wave (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Sinus Wave (Switch).xml** — Info & Integration
- **Sinus Wave (Switch).fx** — Direct3D 9 source code
- **Sinus Wave (Switch).hlsl** — Direct3D 11 source code
- **Sinus Wave (Switch).fxc** — Direct3D 11 compiled
- **Sinus Wave (Switch).fxao** — OpenGL ES (Android) source code
- **Sinus Wave (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*