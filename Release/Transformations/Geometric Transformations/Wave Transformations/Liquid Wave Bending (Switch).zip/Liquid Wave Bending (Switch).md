## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Liquid Wave Bending (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Liquid Wave Bending (Switch).xml** — Info & Integration
- **Liquid Wave Bending (Switch).fx** — Direct3D 9 source code
- **Liquid Wave Bending (Switch).hlsl** — Direct3D 11 source code
- **Liquid Wave Bending (Switch).fxc** — Direct3D 11 compiled
- **Liquid Wave Bending (Switch).fxao** — OpenGL ES (Android) source code
- **Liquid Wave Bending (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*