## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Sinus Wave Offset (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Sinus Wave Offset (Switch).xml** — Info & Integration
- **Sinus Wave Offset (Switch).fx** — Direct3D 9 source code
- **Sinus Wave Offset (Switch).hlsl** — Direct3D 11 source code
- **Sinus Wave Offset (Switch).fxc** — Direct3D 11 compiled
- **Sinus Wave Offset (Switch).fxao** — OpenGL ES (Android) source code
- **Sinus Wave Offset (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*