## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Bulge (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Bulge (Switch).xml** — Info & Integration
- **Bulge (Switch).fx** — Direct3D 9 source code
- **Bulge (Switch).hlsl** — Direct3D 11 source code
- **Bulge (Switch).fxc** — Direct3D 11 compiled
- **Bulge (Switch).fxao** — OpenGL ES (Android) source code
- **Bulge (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*