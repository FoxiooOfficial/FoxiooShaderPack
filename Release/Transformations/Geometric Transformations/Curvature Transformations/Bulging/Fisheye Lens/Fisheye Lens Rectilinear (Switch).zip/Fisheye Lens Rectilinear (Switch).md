## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Fisheye Lens Rectilinear (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Fisheye Lens Rectilinear (Switch).xml** — Info & Integration
- **Fisheye Lens Rectilinear (Switch).fx** — Direct3D 9 source code
- **Fisheye Lens Rectilinear (Switch).hlsl** — Direct3D 11 source code
- **Fisheye Lens Rectilinear (Switch).fxc** — Direct3D 11 compiled
- **Fisheye Lens Rectilinear (Switch).fxao** — OpenGL ES (Android) source code
- **Fisheye Lens Rectilinear (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*