## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Fisheye Lens Equisolid Angle (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Fisheye Lens Equisolid Angle (Switch).xml** — Info & Integration
- **Fisheye Lens Equisolid Angle (Switch).fx** — Direct3D 9 source code
- **Fisheye Lens Equisolid Angle (Switch).hlsl** — Direct3D 11 source code
- **Fisheye Lens Equisolid Angle (Switch).fxc** — Direct3D 11 compiled
- **Fisheye Lens Equisolid Angle (Switch).fxao** — OpenGL ES (Android) source code
- **Fisheye Lens Equisolid Angle (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*