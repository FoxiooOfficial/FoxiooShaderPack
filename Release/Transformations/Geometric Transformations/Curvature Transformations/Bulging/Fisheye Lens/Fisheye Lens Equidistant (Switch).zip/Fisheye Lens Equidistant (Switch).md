## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Fisheye Lens Equidistant (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Fisheye Lens Equidistant (Switch).xml** — Info & Integration
- **Fisheye Lens Equidistant (Switch).fx** — Direct3D 9 source code
- **Fisheye Lens Equidistant (Switch).hlsl** — Direct3D 11 source code
- **Fisheye Lens Equidistant (Switch).fxc** — Direct3D 11 compiled
- **Fisheye Lens Equidistant (Switch).fxao** — OpenGL ES (Android) source code
- **Fisheye Lens Equidistant (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*