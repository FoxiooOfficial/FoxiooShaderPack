## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Pinch (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Pinch (Switch).xml** — Info & Integration
- **Pinch (Switch).fx** — Direct3D 9 source code
- **Pinch (Switch).hlsl** — Direct3D 11 source code
- **Pinch (Switch).fxc** — Direct3D 11 compiled
- **Pinch (Switch).fxao** — OpenGL ES (Android) source code
- **Pinch (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*