## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Bend (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Bend (Switch).xml** — Info & Integration
- **Bend (Switch).fx** — Direct3D 9 source code
- **Bend (Switch).hlsl** — Direct3D 11 source code
- **Bend (Switch).fxc** — Direct3D 11 compiled
- **Bend (Switch).fxao** — OpenGL ES (Android) source code
- **Bend (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*