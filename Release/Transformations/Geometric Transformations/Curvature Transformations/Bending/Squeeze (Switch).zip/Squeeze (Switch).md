## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Squeeze (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Squeeze (Switch).xml** — Info & Integration
- **Squeeze (Switch).fx** — Direct3D 9 source code
- **Squeeze (Switch).hlsl** — Direct3D 11 source code
- **Squeeze (Switch).fxc** — Direct3D 11 compiled
- **Squeeze (Switch).fxao** — OpenGL ES (Android) source code
- **Squeeze (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*