## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Polar (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Polar (Switch).xml** — Info & Integration
- **Polar (Switch).fx** — Direct3D 9 source code
- **Polar (Switch).hlsl** — Direct3D 11 source code
- **Polar (Switch).fxc** — Direct3D 11 compiled
- **Polar (Switch).fxao** — OpenGL ES (Android) source code
- **Polar (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*