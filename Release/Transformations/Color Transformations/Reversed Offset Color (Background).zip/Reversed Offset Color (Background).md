## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Reversed Offset Color (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Reversed Offset Color (Background).xml** — Info & Integration
- **Reversed Offset Color (Background).fx** — Direct3D 9 source code
- **Reversed Offset Color (Background).hlsl** — Direct3D 11 source code
- **Reversed Offset Color (Background).fxc** — Direct3D 11 compiled
- **Reversed Offset Color (Background).fxao** — OpenGL ES (Android) source code
- **Reversed Offset Color (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*