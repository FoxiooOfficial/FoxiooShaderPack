## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Offset Color (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Offset Color (Background).xml** — Info & Integration
- **Offset Color (Background).fx** — Direct3D 9 source code
- **Offset Color (Background).hlsl** — Direct3D 11 source code
- **Offset Color (Background).fxc** — Direct3D 11 compiled
- **Offset Color (Background).fxao** — OpenGL ES (Android) source code
- **Offset Color (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*