## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Self Offset Color (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Self Offset Color (Switch).xml** — Info & Integration
- **Self Offset Color (Switch).fx** — Direct3D 9 source code
- **Self Offset Color (Switch).hlsl** — Direct3D 11 source code
- **Self Offset Color (Switch).fxc** — Direct3D 11 compiled
- **Self Offset Color (Switch).fxao** — OpenGL ES (Android) source code
- **Self Offset Color (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*