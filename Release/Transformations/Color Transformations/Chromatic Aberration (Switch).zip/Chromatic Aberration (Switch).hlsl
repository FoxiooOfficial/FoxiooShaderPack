/***********************************************************/

/* Autor shader: Foxioo */
/* Version shader: 1.1 (18.10.2025) */
/* My GitHub: https://github.com/FoxiooOfficial */

/***********************************************************/

/* ####################################################### */

/***********************************************************/
/* Samplers */
/***********************************************************/


Texture2D<float4> S2D_Image : register(t0);
SamplerState S2D_ImageSampler : register(s0);

Texture2D<float4> S2D_Background : register(t1);
SamplerState S2D_BackgroundSampler : register(s1);

/***********************************************************/
/* Varibles */
/***********************************************************/


cbuffer PS_VARIABLES : register(b0)
{
    bool _;
    bool __;
    float _PosXRed;
    float _PosYRed;
    float _PosXGreen;
    float _PosYGreen;
    float _PosXBlue;
    float _PosYBlue;
    bool ___;
    float _RotXRed;
    float _RotXGreen;
    float _RotXBlue;
    bool ____;
    float _PointXRed;
    float _PointYRed;
    float _PointXGreen;
    float _PointYGreen;
    float _PointXBlue;
    float _PointYBlue;
    bool _____;        
    float _ScaleRed;
    float _ScaleXRed;
    float _ScaleYRed;
    float _ScaleGreen;
    float _ScaleXGreen;
    float _ScaleYGreen;
    float _ScaleBlue;
    float _ScaleXBlue;
    float _ScaleYBlue;
    bool ______;
    int _Looping_Mode;
    bool _Blending_Mode;
    float _Mixing;
    bool _______;
	bool _Is_Pre_296_Build;
	bool ________;
};

struct PS_INPUT
{
  float4 Tint : COLOR0;
  float2 texCoord : TEXCOORD0;
};

struct PS_OUTPUT
{
    float4 Color   : SV_TARGET;
};

cbuffer PS_PIXELSIZE : register(b1)
{
	float fPixelWidth;
	float fPixelHeight;
};

/************************************************************/
/* Main */
/************************************************************/

float2 Fun_RotationX(float2 In, float _RotX, float _PointX, float _PointY)
{
    float2 _Points = float2(_PointX, _PointY);
    float2 _UV = In;
    float _RotX_Fix = _RotX * (3.14159265 / 180);

        _UV = _Points + mul(float2x2(cos(_RotX_Fix), sin(_RotX_Fix), -sin(_RotX_Fix), cos(_RotX_Fix)), _UV - _Points);

    return _UV;
}

float2 Fun_ChannelUV(float2 In, float _PosX, float _PosY, float _PointX, float _PointY, float _ScaleX, float _ScaleY, float _Scale, float _RotX)
{
    float2  _Pos = float2(_PosX, _PosY),
        UV = (Fun_RotationX(In + _Pos, _RotX, _PointX, _PointY) - float2(_PointX, _PointY) * float2(_ScaleX, _ScaleY) * _Scale) + float2(_PointX, _PointY);

    return UV;
}

PS_OUTPUT ps_main( in PS_INPUT In )
{ 
    PS_OUTPUT Out;

    float4 _Render_Texture = S2D_Image.Sample(S2D_ImageSampler, In.texCoord) * In.Tint;
    //float4 _Render_Background = S2D_Background.Sample(S2D_BackgroundSampler, In.texCoord);
    float4 _Render = 0;

    float2 _UVRed =     lerp(In.texCoord, Fun_ChannelUV(In.texCoord, _PosXRed, _PosYRed, _PointXRed, _PointYRed, _ScaleXRed, _ScaleYRed, _ScaleRed, _RotXRed), _Mixing);
    float2 _UVGreen =   lerp(In.texCoord, Fun_ChannelUV(In.texCoord, _PosXGreen, _PosYGreen, _PointXGreen, _PointYGreen, _ScaleXGreen, _ScaleYGreen, _ScaleGreen, _RotXGreen), _Mixing);
    float2 _UVBlue =    lerp(In.texCoord, Fun_ChannelUV(In.texCoord, _PosXBlue, _PosYBlue, _PointXBlue, _PointYBlue, _ScaleXBlue, _ScaleYBlue, _ScaleBlue, _RotXBlue), _Mixing);

        if (_Looping_Mode == 0) {
            _UVRed = frac(_UVRed);
            _UVGreen = frac(_UVGreen);
            _UVBlue = frac(_UVBlue);
        }
        else if(_Looping_Mode == 1)
        {
            _UVRed = abs(frac(_UVRed / 2.0) * 2.0 - 1.0);
            _UVGreen = abs(frac(_UVGreen / 2.0) * 2.0 - 1.0);
            _UVBlue = abs(frac(_UVBlue / 2.0) * 2.0 - 1.0);
        }
        else if(_Looping_Mode == 2)
        {
            _UVRed = clamp(_UVRed, 0.0, 1.0);
            _UVGreen = clamp(_UVGreen, 0.0, 1.0);
            _UVBlue = clamp(_UVBlue, 0.0, 1.0);
        }

    if(_Blending_Mode == 0) {   _Render = float4(   S2D_Image.Sample(S2D_ImageSampler, _UVRed).r,
                                                    S2D_Image.Sample(S2D_ImageSampler, _UVGreen).g, 
                                                    S2D_Image.Sample(S2D_ImageSampler, _UVBlue).b, 
                                                    S2D_Image.Sample(S2D_ImageSampler, _UVRed).a * S2D_Image.Sample(S2D_ImageSampler, _UVGreen).a * S2D_Image.Sample(S2D_ImageSampler, _UVBlue).a ) * In.Tint;  }

    else {                      _Render = float4(   S2D_Background.Sample(S2D_BackgroundSampler, _UVRed).r, 
                                                    S2D_Background.Sample(S2D_BackgroundSampler, _UVGreen).g, 
                                                    S2D_Background.Sample(S2D_BackgroundSampler, _UVBlue).b, 
                                                    _Render_Texture.a * S2D_Background.Sample(S2D_BackgroundSampler, _UVRed).a * S2D_Background.Sample(S2D_BackgroundSampler, _UVGreen).a * S2D_Background.Sample(S2D_BackgroundSampler, _UVBlue).a * In.Tint.a);             }

        if (_Looping_Mode == 3)
        {
            if (any(_UVRed <= 0.0 || _UVRed >= 1.0)) { _Render.a = 0.0; }
            if (any(_UVGreen <= 0.0 || _UVGreen >= 1.0)) { _Render.a = 0.0; }
            if (any(_UVBlue <= 0.0 || _UVBlue >= 1.0)) { _Render.a = 0.0; }
        }

    Out.Color = _Render;
    return Out;
}

/************************************************************/
/* Premultiplied Alpha */
/************************************************************/

float4 Demultiply(float4 _Color)
{
	if ( _Color.a != 0 )   _Color.rgb /= _Color.a;
	return _Color;
}

PS_OUTPUT ps_main_pm( in PS_INPUT In )
{ 
    PS_OUTPUT Out;

    float4 _Render_Texture = Demultiply(S2D_Image.Sample(S2D_ImageSampler, In.texCoord)) * In.Tint;
    //float4 _Render_Background = S2D_Background.Sample(S2D_BackgroundSampler, In.texCoord);
    float4 _Render = 0;

    float2 _UVRed =     lerp(In.texCoord, Fun_ChannelUV(In.texCoord, _PosXRed, _PosYRed, _PointXRed, _PointYRed, _ScaleXRed, _ScaleYRed, _ScaleRed, _RotXRed), _Mixing);
    float2 _UVGreen =   lerp(In.texCoord, Fun_ChannelUV(In.texCoord, _PosXGreen, _PosYGreen, _PointXGreen, _PointYGreen, _ScaleXGreen, _ScaleYGreen, _ScaleGreen, _RotXGreen), _Mixing);
    float2 _UVBlue =    lerp(In.texCoord, Fun_ChannelUV(In.texCoord, _PosXBlue, _PosYBlue, _PointXBlue, _PointYBlue, _ScaleXBlue, _ScaleYBlue, _ScaleBlue, _RotXBlue), _Mixing);

        if (_Looping_Mode == 0) {
            _UVRed = frac(_UVRed);
            _UVGreen = frac(_UVGreen);
            _UVBlue = frac(_UVBlue);
        }
        else if(_Looping_Mode == 1)
        {
            _UVRed = abs(frac(_UVRed / 2.0) * 2.0 - 1.0);
            _UVGreen = abs(frac(_UVGreen / 2.0) * 2.0 - 1.0);
            _UVBlue = abs(frac(_UVBlue / 2.0) * 2.0 - 1.0);
        }
        else if(_Looping_Mode == 2)
        {
            _UVRed = clamp(_UVRed, 0.0, 1.0);
            _UVGreen = clamp(_UVGreen, 0.0, 1.0);
            _UVBlue = clamp(_UVBlue, 0.0, 1.0);
        }

    if(_Blending_Mode == 0) {   _Render = Demultiply(float4(   S2D_Image.Sample(S2D_ImageSampler, _UVRed).r,
                                                    S2D_Image.Sample(S2D_ImageSampler, _UVGreen).g, 
                                                    S2D_Image.Sample(S2D_ImageSampler, _UVBlue).b, 
                                                    S2D_Image.Sample(S2D_ImageSampler, _UVRed).a * S2D_Image.Sample(S2D_ImageSampler, _UVGreen).a * S2D_Image.Sample(S2D_ImageSampler, _UVBlue).a )) * In.Tint;  }

    else {                      _Render = float4(   S2D_Background.Sample(S2D_BackgroundSampler, _UVRed).r, 
                                                    S2D_Background.Sample(S2D_BackgroundSampler, _UVGreen).g, 
                                                    S2D_Background.Sample(S2D_BackgroundSampler, _UVBlue).b, 
                                                    _Render_Texture.a * S2D_Background.Sample(S2D_BackgroundSampler, _UVRed).a * S2D_Background.Sample(S2D_BackgroundSampler, _UVGreen).a * S2D_Background.Sample(S2D_BackgroundSampler, _UVBlue).a * In.Tint.a);             }

        if (_Looping_Mode == 3)
        {
            if (any(_UVRed <= 0.0 || _UVRed >= 1.0)) { _Render.a = 0.0; }
            if (any(_UVGreen <= 0.0 || _UVGreen >= 1.0)) { _Render.a = 0.0; }
            if (any(_UVBlue <= 0.0 || _UVBlue >= 1.0)) { _Render.a = 0.0; }
        }

    _Render.rgb *= _Render.a;

    Out.Color = _Render;
    return Out;
}
