## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Chromatic Aberration (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Chromatic Aberration (Switch).xml** — Info & Integration
- **Chromatic Aberration (Switch).fx** — Direct3D 9 source code
- **Chromatic Aberration (Switch).hlsl** — Direct3D 11 source code
- **Chromatic Aberration (Switch).fxc** — Direct3D 11 compiled
- **Chromatic Aberration (Switch).fxao** — OpenGL ES (Android) source code
- **Chromatic Aberration (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*