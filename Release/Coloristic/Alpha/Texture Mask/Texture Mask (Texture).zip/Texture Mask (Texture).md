## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Texture Mask (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Texture Mask (Texture).xml** — Info & Integration
- **Texture Mask (Texture).fx** — Direct3D 9 source code
- **Texture Mask (Texture).hlsl** — Direct3D 11 source code
- **Texture Mask (Texture).fxc** — Direct3D 11 compiled
- **Texture Mask (Texture).fxao** — OpenGL ES (Android) source code
- **Texture Mask (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Textures
- TEXTUREMASK_9.png
- TEXTUREMASK_7.png
- TEXTUREMASK_0.png
- TEXTUREMASK_1.png
- TEXTUREMASK_10.png
- TEXTUREMASK_2.png
- TEXTUREMASK_5.png
- TEXTUREMASK_3.png
- TEXTUREMASK_6.png
- TEXTUREMASK_4.png
- TEXTUREMASK_8.png