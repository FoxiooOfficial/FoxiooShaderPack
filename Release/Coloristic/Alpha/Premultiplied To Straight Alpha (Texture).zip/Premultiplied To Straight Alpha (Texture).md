## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Premultiplied To Straight Alpha (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Premultiplied To Straight Alpha (Texture).xml** — Info & Integration
- **Premultiplied To Straight Alpha (Texture).fx** — Direct3D 9 source code
- **Premultiplied To Straight Alpha (Texture).hlsl** — Direct3D 11 source code
- **Premultiplied To Straight Alpha (Texture).fxc** — Direct3D 11 compiled
- **Premultiplied To Straight Alpha (Texture).fxao** — OpenGL ES (Android) source code
- **Premultiplied To Straight Alpha (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*