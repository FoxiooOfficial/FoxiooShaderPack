## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Straight To Premultiplied Alpha (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Straight To Premultiplied Alpha (Texture).xml** — Info & Integration
- **Straight To Premultiplied Alpha (Texture).fx** — Direct3D 9 source code
- **Straight To Premultiplied Alpha (Texture).hlsl** — Direct3D 11 source code
- **Straight To Premultiplied Alpha (Texture).fxc** — Direct3D 11 compiled
- **Straight To Premultiplied Alpha (Texture).fxao** — OpenGL ES (Android) source code
- **Straight To Premultiplied Alpha (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*