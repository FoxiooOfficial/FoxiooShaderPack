## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Bubble Mask (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Bubble Mask (Texture).xml** — Info & Integration
- **Bubble Mask (Texture).fx** — Direct3D 9 source code
- **Bubble Mask (Texture).hlsl** — Direct3D 11 source code
- **Bubble Mask (Texture).fxc** — Direct3D 11 compiled
- **Bubble Mask (Texture).fxao** — OpenGL ES (Android) source code
- **Bubble Mask (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*