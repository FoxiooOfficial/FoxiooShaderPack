## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Chroma Key Color (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Chroma Key Color (Texture).xml** — Info & Integration
- **Chroma Key Color (Texture).fx** — Direct3D 9 source code
- **Chroma Key Color (Texture).hlsl** — Direct3D 11 source code
- **Chroma Key Color (Texture).fxc** — Direct3D 11 compiled
- **Chroma Key Color (Texture).fxao** — OpenGL ES (Android) source code
- **Chroma Key Color (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*