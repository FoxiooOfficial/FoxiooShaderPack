## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Chroma Key Inverted (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Chroma Key Inverted (Texture).xml** — Info & Integration
- **Chroma Key Inverted (Texture).fx** — Direct3D 9 source code
- **Chroma Key Inverted (Texture).hlsl** — Direct3D 11 source code
- **Chroma Key Inverted (Texture).fxc** — Direct3D 11 compiled
- **Chroma Key Inverted (Texture).fxao** — OpenGL ES (Android) source code
- **Chroma Key Inverted (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*