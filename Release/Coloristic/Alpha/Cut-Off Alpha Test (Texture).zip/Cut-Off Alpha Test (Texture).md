## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Cut-Off Alpha Test (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Cut-Off Alpha Test (Texture).xml** — Info & Integration
- **Cut-Off Alpha Test (Texture).fx** — Direct3D 9 source code
- **Cut-Off Alpha Test (Texture).hlsl** — Direct3D 11 source code
- **Cut-Off Alpha Test (Texture).fxc** — Direct3D 11 compiled
- **Cut-Off Alpha Test (Texture).fxao** — OpenGL ES (Android) source code
- **Cut-Off Alpha Test (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*