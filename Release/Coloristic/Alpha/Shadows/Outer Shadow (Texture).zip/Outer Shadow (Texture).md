## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Outer Shadow (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Outer Shadow (Texture).xml** — Info & Integration
- **Outer Shadow (Texture).fx** — Direct3D 9 source code
- **Outer Shadow (Texture).hlsl** — Direct3D 11 source code
- **Outer Shadow (Texture).fxc** — Direct3D 11 compiled
- **Outer Shadow (Texture).fxao** — OpenGL ES (Android) source code
- **Outer Shadow (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*