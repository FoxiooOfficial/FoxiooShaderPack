## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Inner Shadow (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Inner Shadow (Texture).xml** — Info & Integration
- **Inner Shadow (Texture).fx** — Direct3D 9 source code
- **Inner Shadow (Texture).hlsl** — Direct3D 11 source code
- **Inner Shadow (Texture).fxc** — Direct3D 11 compiled
- **Inner Shadow (Texture).fxao** — OpenGL ES (Android) source code
- **Inner Shadow (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*