## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Invert Brightness (Switch) [Rework].premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Invert Brightness (Switch) [Rework].xml** — Info & Integration
- **Invert Brightness (Switch) [Rework].fx** — Direct3D 9 source code
- **Invert Brightness (Switch) [Rework].hlsl** — Direct3D 11 source code
- **Invert Brightness (Switch) [Rework].fxc** — Direct3D 11 compiled
- **Invert Brightness (Switch) [Rework].fxao** — OpenGL ES (Android) source code
- **Invert Brightness (Switch) [Rework].fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*