## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Invert Brightness (Switch) [Legacy].premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Invert Brightness (Switch) [Legacy].xml** — Info & Integration
- **Invert Brightness (Switch) [Legacy].fx** — Direct3D 9 source code
- **Invert Brightness (Switch) [Legacy].hlsl** — Direct3D 11 source code
- **Invert Brightness (Switch) [Legacy].fxc** — Direct3D 11 compiled
- **Invert Brightness (Switch) [Legacy].fxao** — OpenGL ES (Android) source code
- **Invert Brightness (Switch) [Legacy].fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*