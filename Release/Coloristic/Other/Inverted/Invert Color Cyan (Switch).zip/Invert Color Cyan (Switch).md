## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Invert Color Cyan (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Invert Color Cyan (Switch).xml** — Info & Integration
- **Invert Color Cyan (Switch).fx** — Direct3D 9 source code
- **Invert Color Cyan (Switch).hlsl** — Direct3D 11 source code
- **Invert Color Cyan (Switch).fxc** — Direct3D 11 compiled
- **Invert Color Cyan (Switch).fxao** — OpenGL ES (Android) source code
- **Invert Color Cyan (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*