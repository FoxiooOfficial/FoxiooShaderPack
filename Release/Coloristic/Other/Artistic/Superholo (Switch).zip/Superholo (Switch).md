## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Superholo (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Superholo (Switch).xml** — Info & Integration
- **Superholo (Switch).fx** — Direct3D 9 source code
- **Superholo (Switch).hlsl** — Direct3D 11 source code
- **Superholo (Switch).fxc** — Direct3D 11 compiled
- **Superholo (Switch).fxao** — OpenGL ES (Android) source code
- **Superholo (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*