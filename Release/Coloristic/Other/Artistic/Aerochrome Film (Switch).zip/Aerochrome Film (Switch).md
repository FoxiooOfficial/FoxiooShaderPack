## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Aerochrome Film (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Aerochrome Film (Switch).xml** — Info & Integration
- **Aerochrome Film (Switch).fx** — Direct3D 9 source code
- **Aerochrome Film (Switch).hlsl** — Direct3D 11 source code
- **Aerochrome Film (Switch).fxc** — Direct3D 11 compiled
- **Aerochrome Film (Switch).fxao** — OpenGL ES (Android) source code
- **Aerochrome Film (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*