## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Photographic Film Negative (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photographic Film Negative (Switch).xml** — Info & Integration
- **Photographic Film Negative (Switch).fx** — Direct3D 9 source code
- **Photographic Film Negative (Switch).hlsl** — Direct3D 11 source code
- **Photographic Film Negative (Switch).fxc** — Direct3D 11 compiled
- **Photographic Film Negative (Switch).fxao** — OpenGL ES (Android) source code
- **Photographic Film Negative (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*