## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Simulation Color Blindness AIO (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Simulation Color Blindness AIO (Switch).xml** — Info & Integration
- **Simulation Color Blindness AIO (Switch).fx** — Direct3D 9 source code
- **Simulation Color Blindness AIO (Switch).hlsl** — Direct3D 11 source code
- **Simulation Color Blindness AIO (Switch).fxc** — Direct3D 11 compiled
- **Simulation Color Blindness AIO (Switch).fxao** — OpenGL ES (Android) source code
- **Simulation Color Blindness AIO (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*