## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Simulation Of Protanopia (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Simulation Of Protanopia (Switch).xml** — Info & Integration
- **Simulation Of Protanopia (Switch).fx** — Direct3D 9 source code
- **Simulation Of Protanopia (Switch).hlsl** — Direct3D 11 source code
- **Simulation Of Protanopia (Switch).fxc** — Direct3D 11 compiled
- **Simulation Of Protanopia (Switch).fxao** — OpenGL ES (Android) source code
- **Simulation Of Protanopia (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*