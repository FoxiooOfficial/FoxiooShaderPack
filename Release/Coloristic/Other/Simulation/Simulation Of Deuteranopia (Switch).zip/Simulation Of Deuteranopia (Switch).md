## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Simulation Of Deuteranopia (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Simulation Of Deuteranopia (Switch).xml** — Info & Integration
- **Simulation Of Deuteranopia (Switch).fx** — Direct3D 9 source code
- **Simulation Of Deuteranopia (Switch).hlsl** — Direct3D 11 source code
- **Simulation Of Deuteranopia (Switch).fxc** — Direct3D 11 compiled
- **Simulation Of Deuteranopia (Switch).fxao** — OpenGL ES (Android) source code
- **Simulation Of Deuteranopia (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*