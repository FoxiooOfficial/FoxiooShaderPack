## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Simulation Of Achromatomaly (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Simulation Of Achromatomaly (Switch).xml** — Info & Integration
- **Simulation Of Achromatomaly (Switch).fx** — Direct3D 9 source code
- **Simulation Of Achromatomaly (Switch).hlsl** — Direct3D 11 source code
- **Simulation Of Achromatomaly (Switch).fxc** — Direct3D 11 compiled
- **Simulation Of Achromatomaly (Switch).fxao** — OpenGL ES (Android) source code
- **Simulation Of Achromatomaly (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*