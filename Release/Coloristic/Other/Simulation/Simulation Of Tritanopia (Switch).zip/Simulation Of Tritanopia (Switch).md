## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Simulation Of Tritanopia (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Simulation Of Tritanopia (Switch).xml** — Info & Integration
- **Simulation Of Tritanopia (Switch).fx** — Direct3D 9 source code
- **Simulation Of Tritanopia (Switch).hlsl** — Direct3D 11 source code
- **Simulation Of Tritanopia (Switch).fxc** — Direct3D 11 compiled
- **Simulation Of Tritanopia (Switch).fxao** — OpenGL ES (Android) source code
- **Simulation Of Tritanopia (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*