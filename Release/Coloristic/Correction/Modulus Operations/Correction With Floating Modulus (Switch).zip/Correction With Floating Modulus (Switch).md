## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Correction With Floating Modulus (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Correction With Floating Modulus (Switch).xml** — Info & Integration
- **Correction With Floating Modulus (Switch).fx** — Direct3D 9 source code
- **Correction With Floating Modulus (Switch).hlsl** — Direct3D 11 source code
- **Correction With Floating Modulus (Switch).fxc** — Direct3D 11 compiled
- **Correction With Floating Modulus (Switch).fxao** — OpenGL ES (Android) source code
- **Correction With Floating Modulus (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*