## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Correction With Round (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Correction With Round (Switch).xml** — Info & Integration
- **Correction With Round (Switch).fx** — Direct3D 9 source code
- **Correction With Round (Switch).hlsl** — Direct3D 11 source code
- **Correction With Round (Switch).fxc** — Direct3D 11 compiled
- **Correction With Round (Switch).fxao** — OpenGL ES (Android) source code
- **Correction With Round (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*