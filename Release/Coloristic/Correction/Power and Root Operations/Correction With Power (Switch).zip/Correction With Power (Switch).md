## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Correction With Power (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Correction With Power (Switch).xml** — Info & Integration
- **Correction With Power (Switch).fx** — Direct3D 9 source code
- **Correction With Power (Switch).hlsl** — Direct3D 11 source code
- **Correction With Power (Switch).fxc** — Direct3D 11 compiled
- **Correction With Power (Switch).fxao** — OpenGL ES (Android) source code
- **Correction With Power (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*