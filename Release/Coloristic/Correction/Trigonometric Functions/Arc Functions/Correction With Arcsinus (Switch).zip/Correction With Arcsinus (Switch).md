## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Correction With Arcsinus (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Correction With Arcsinus (Switch).xml** — Info & Integration
- **Correction With Arcsinus (Switch).fx** — Direct3D 9 source code
- **Correction With Arcsinus (Switch).hlsl** — Direct3D 11 source code
- **Correction With Arcsinus (Switch).fxc** — Direct3D 11 compiled
- **Correction With Arcsinus (Switch).fxao** — OpenGL ES (Android) source code
- **Correction With Arcsinus (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*