## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Correction With Arccosinus (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Correction With Arccosinus (Switch).xml** — Info & Integration
- **Correction With Arccosinus (Switch).fx** — Direct3D 9 source code
- **Correction With Arccosinus (Switch).hlsl** — Direct3D 11 source code
- **Correction With Arccosinus (Switch).fxc** — Direct3D 11 compiled
- **Correction With Arccosinus (Switch).fxao** — OpenGL ES (Android) source code
- **Correction With Arccosinus (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*