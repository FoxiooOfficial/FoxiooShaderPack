## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Correction With Arctangent (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Correction With Arctangent (Switch).xml** — Info & Integration
- **Correction With Arctangent (Switch).fx** — Direct3D 9 source code
- **Correction With Arctangent (Switch).hlsl** — Direct3D 11 source code
- **Correction With Arctangent (Switch).fxc** — Direct3D 11 compiled
- **Correction With Arctangent (Switch).fxao** — OpenGL ES (Android) source code
- **Correction With Arctangent (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*