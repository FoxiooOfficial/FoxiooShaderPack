## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Correction With Cotangent (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Correction With Cotangent (Switch).xml** — Info & Integration
- **Correction With Cotangent (Switch).fx** — Direct3D 9 source code
- **Correction With Cotangent (Switch).hlsl** — Direct3D 11 source code
- **Correction With Cotangent (Switch).fxc** — Direct3D 11 compiled
- **Correction With Cotangent (Switch).fxao** — OpenGL ES (Android) source code
- **Correction With Cotangent (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*