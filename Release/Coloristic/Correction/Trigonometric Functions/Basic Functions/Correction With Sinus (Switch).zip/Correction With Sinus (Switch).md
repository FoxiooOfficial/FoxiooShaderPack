## Info
**Last Updated:** 2026-04-13 21:10  

## Shader files
- **Correction With Sinus (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Correction With Sinus (Switch).xml** — Info & Integration
- **Correction With Sinus (Switch).fx** — Direct3D 9 source code
- **Correction With Sinus (Switch).hlsl** — Direct3D 11 source code
- **Correction With Sinus (Switch).fxc** — Direct3D 11 compiled
- **Correction With Sinus (Switch).fxao** — OpenGL ES (Android) source code
- **Correction With Sinus (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*