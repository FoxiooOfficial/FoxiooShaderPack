## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Correction With Hyperbolic Secant (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Correction With Hyperbolic Secant (Switch).xml** — Info & Integration
- **Correction With Hyperbolic Secant (Switch).fx** — Direct3D 9 source code
- **Correction With Hyperbolic Secant (Switch).hlsl** — Direct3D 11 source code
- **Correction With Hyperbolic Secant (Switch).fxc** — Direct3D 11 compiled
- **Correction With Hyperbolic Secant (Switch).fxao** — OpenGL ES (Android) source code
- **Correction With Hyperbolic Secant (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*