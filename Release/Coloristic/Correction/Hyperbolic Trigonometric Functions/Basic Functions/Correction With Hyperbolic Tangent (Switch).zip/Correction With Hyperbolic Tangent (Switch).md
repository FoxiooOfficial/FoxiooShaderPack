## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Correction With Hyperbolic Tangent (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Correction With Hyperbolic Tangent (Switch).xml** — Info & Integration
- **Correction With Hyperbolic Tangent (Switch).fx** — Direct3D 9 source code
- **Correction With Hyperbolic Tangent (Switch).hlsl** — Direct3D 11 source code
- **Correction With Hyperbolic Tangent (Switch).fxc** — Direct3D 11 compiled
- **Correction With Hyperbolic Tangent (Switch).fxao** — OpenGL ES (Android) source code
- **Correction With Hyperbolic Tangent (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*