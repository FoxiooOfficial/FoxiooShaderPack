## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Conversion To YUV (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Conversion To YUV (Switch).xml** — Info & Integration
- **Conversion To YUV (Switch).fx** — Direct3D 9 source code
- **Conversion To YUV (Switch).hlsl** — Direct3D 11 source code
- **Conversion To YUV (Switch).fxc** — Direct3D 11 compiled
- **Conversion To YUV (Switch).fxao** — OpenGL ES (Android) source code
- **Conversion To YUV (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*