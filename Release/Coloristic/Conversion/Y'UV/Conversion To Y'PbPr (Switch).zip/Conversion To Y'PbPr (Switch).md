## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Conversion To Y'PbPr (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Conversion To Y'PbPr (Switch).xml** — Info & Integration
- **Conversion To Y'PbPr (Switch).fx** — Direct3D 9 source code
- **Conversion To Y'PbPr (Switch).hlsl** — Direct3D 11 source code
- **Conversion To Y'PbPr (Switch).fxc** — Direct3D 11 compiled
- **Conversion To Y'PbPr (Switch).fxao** — OpenGL ES (Android) source code
- **Conversion To Y'PbPr (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*