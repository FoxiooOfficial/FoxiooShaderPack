## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Conversion To Y'DbDr (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Conversion To Y'DbDr (Switch).xml** — Info & Integration
- **Conversion To Y'DbDr (Switch).fx** — Direct3D 9 source code
- **Conversion To Y'DbDr (Switch).hlsl** — Direct3D 11 source code
- **Conversion To Y'DbDr (Switch).fxc** — Direct3D 11 compiled
- **Conversion To Y'DbDr (Switch).fxao** — OpenGL ES (Android) source code
- **Conversion To Y'DbDr (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*