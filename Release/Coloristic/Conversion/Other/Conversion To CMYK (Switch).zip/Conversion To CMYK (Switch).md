## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Conversion To CMYK (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Conversion To CMYK (Switch).xml** — Info & Integration
- **Conversion To CMYK (Switch).fx** — Direct3D 9 source code
- **Conversion To CMYK (Switch).hlsl** — Direct3D 11 source code
- **Conversion To CMYK (Switch).fxc** — Direct3D 11 compiled
- **Conversion To CMYK (Switch).fxao** — OpenGL ES (Android) source code
- **Conversion To CMYK (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*