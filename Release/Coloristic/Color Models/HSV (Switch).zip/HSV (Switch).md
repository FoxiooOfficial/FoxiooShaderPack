## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **HSV (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **HSV (Switch).xml** — Info & Integration
- **HSV (Switch).fx** — Direct3D 9 source code
- **HSV (Switch).hlsl** — Direct3D 11 source code
- **HSV (Switch).fxc** — Direct3D 11 compiled
- **HSV (Switch).fxao** — OpenGL ES (Android) source code
- **HSV (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*