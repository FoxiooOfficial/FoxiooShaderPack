## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **HSL (Switch) [Legacy].premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **HSL (Switch) [Legacy].xml** — Info & Integration
- **HSL (Switch) [Legacy].fx** — Direct3D 9 source code
- **HSL (Switch) [Legacy].hlsl** — Direct3D 11 source code
- **HSL (Switch) [Legacy].fxc** — Direct3D 11 compiled
- **HSL (Switch) [Legacy].fxao** — OpenGL ES (Android) source code
- **HSL (Switch) [Legacy].fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*

## Examples
- ChangeHue.mfa

*The examples may require additional effects or extensions.*