## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **CIELab (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **CIELab (Switch).xml** — Info & Integration
- **CIELab (Switch).fx** — Direct3D 9 source code
- **CIELab (Switch).hlsl** — Direct3D 11 source code
- **CIELab (Switch).fxc** — Direct3D 11 compiled
- **CIELab (Switch).fxao** — OpenGL ES (Android) source code
- **CIELab (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*