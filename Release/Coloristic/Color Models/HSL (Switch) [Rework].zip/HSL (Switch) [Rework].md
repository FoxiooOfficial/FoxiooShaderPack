## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **HSL (Switch) [Rework].premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **HSL (Switch) [Rework].xml** — Info & Integration
- **HSL (Switch) [Rework].fx** — Direct3D 9 source code
- **HSL (Switch) [Rework].hlsl** — Direct3D 11 source code
- **HSL (Switch) [Rework].fxc** — Direct3D 11 compiled
- **HSL (Switch) [Rework].fxao** — OpenGL ES (Android) source code
- **HSL (Switch) [Rework].fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*