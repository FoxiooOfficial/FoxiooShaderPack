## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **CMYK (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **CMYK (Switch).xml** — Info & Integration
- **CMYK (Switch).fx** — Direct3D 9 source code
- **CMYK (Switch).hlsl** — Direct3D 11 source code
- **CMYK (Switch).fxc** — Direct3D 11 compiled
- **CMYK (Switch).fxao** — OpenGL ES (Android) source code
- **CMYK (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*