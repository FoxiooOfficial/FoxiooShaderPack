## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **HSI (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **HSI (Switch).xml** — Info & Integration
- **HSI (Switch).fx** — Direct3D 9 source code
- **HSI (Switch).hlsl** — Direct3D 11 source code
- **HSI (Switch).fxc** — Direct3D 11 compiled
- **HSI (Switch).fxao** — OpenGL ES (Android) source code
- **HSI (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*