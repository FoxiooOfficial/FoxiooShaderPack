## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Daytime (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Daytime (Switch).xml** — Info & Integration
- **Daytime (Switch).fx** — Direct3D 9 source code
- **Daytime (Switch).hlsl** — Direct3D 11 source code
- **Daytime (Switch).fxc** — Direct3D 11 compiled
- **Daytime (Switch).fxao** — OpenGL ES (Android) source code
- **Daytime (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*