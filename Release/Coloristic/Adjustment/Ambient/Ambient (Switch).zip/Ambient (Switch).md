## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Ambient (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Ambient (Switch).xml** — Info & Integration
- **Ambient (Switch).fx** — Direct3D 9 source code
- **Ambient (Switch).hlsl** — Direct3D 11 source code
- **Ambient (Switch).fxc** — Direct3D 11 compiled
- **Ambient (Switch).fxao** — OpenGL ES (Android) source code
- **Ambient (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*