## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Temperature (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Temperature (Switch).xml** — Info & Integration
- **Temperature (Switch).fx** — Direct3D 9 source code
- **Temperature (Switch).hlsl** — Direct3D 11 source code
- **Temperature (Switch).fxc** — Direct3D 11 compiled
- **Temperature (Switch).fxao** — OpenGL ES (Android) source code
- **Temperature (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*