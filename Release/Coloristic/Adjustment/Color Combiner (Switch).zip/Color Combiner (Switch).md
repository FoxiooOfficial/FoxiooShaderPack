## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Color Combiner (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Color Combiner (Switch).xml** — Info & Integration
- **Color Combiner (Switch).fx** — Direct3D 9 source code
- **Color Combiner (Switch).hlsl** — Direct3D 11 source code
- **Color Combiner (Switch).fxc** — Direct3D 11 compiled
- **Color Combiner (Switch).fxao** — OpenGL ES (Android) source code
- **Color Combiner (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*