## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Sepia (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Sepia (Switch).xml** — Info & Integration
- **Sepia (Switch).fx** — Direct3D 9 source code
- **Sepia (Switch).hlsl** — Direct3D 11 source code
- **Sepia (Switch).fxc** — Direct3D 11 compiled
- **Sepia (Switch).fxao** — OpenGL ES (Android) source code
- **Sepia (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*