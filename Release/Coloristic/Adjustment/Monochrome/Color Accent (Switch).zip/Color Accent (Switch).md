## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Color Accent (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Color Accent (Switch).xml** — Info & Integration
- **Color Accent (Switch).fx** — Direct3D 9 source code
- **Color Accent (Switch).hlsl** — Direct3D 11 source code
- **Color Accent (Switch).fxc** — Direct3D 11 compiled
- **Color Accent (Switch).fxao** — OpenGL ES (Android) source code
- **Color Accent (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*