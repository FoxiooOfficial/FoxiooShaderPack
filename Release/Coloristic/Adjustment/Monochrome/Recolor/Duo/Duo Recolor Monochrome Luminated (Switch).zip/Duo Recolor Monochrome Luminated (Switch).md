## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Duo Recolor Monochrome Luminated (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Duo Recolor Monochrome Luminated (Switch).xml** — Info & Integration
- **Duo Recolor Monochrome Luminated (Switch).fx** — Direct3D 9 source code
- **Duo Recolor Monochrome Luminated (Switch).hlsl** — Direct3D 11 source code
- **Duo Recolor Monochrome Luminated (Switch).fxc** — Direct3D 11 compiled
- **Duo Recolor Monochrome Luminated (Switch).fxao** — OpenGL ES (Android) source code
- **Duo Recolor Monochrome Luminated (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*