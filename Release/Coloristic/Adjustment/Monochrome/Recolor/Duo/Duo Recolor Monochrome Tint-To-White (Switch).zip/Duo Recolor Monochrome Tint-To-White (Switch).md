## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Duo Recolor Monochrome Tint-To-White (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Duo Recolor Monochrome Tint-To-White (Switch).xml** — Info & Integration
- **Duo Recolor Monochrome Tint-To-White (Switch).fx** — Direct3D 9 source code
- **Duo Recolor Monochrome Tint-To-White (Switch).hlsl** — Direct3D 11 source code
- **Duo Recolor Monochrome Tint-To-White (Switch).fxc** — Direct3D 11 compiled
- **Duo Recolor Monochrome Tint-To-White (Switch).fxao** — OpenGL ES (Android) source code
- **Duo Recolor Monochrome Tint-To-White (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*