## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Recolor Monochrome Luminated (Switch).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Recolor Monochrome Luminated (Switch).xml** — Info & Integration
- **Recolor Monochrome Luminated (Switch).fx** — Direct3D 9 source code
- **Recolor Monochrome Luminated (Switch).hlsl** — Direct3D 11 source code
- **Recolor Monochrome Luminated (Switch).fxc** — Direct3D 11 compiled
- **Recolor Monochrome Luminated (Switch).fxao** — OpenGL ES (Android) source code
- **Recolor Monochrome Luminated (Switch).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*