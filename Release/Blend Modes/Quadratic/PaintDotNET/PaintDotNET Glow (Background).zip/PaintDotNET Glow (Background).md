## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **PaintDotNET Glow (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **PaintDotNET Glow (Background).xml** — Info & Integration
- **PaintDotNET Glow (Background).fx** — Direct3D 9 source code
- **PaintDotNET Glow (Background).hlsl** — Direct3D 11 source code
- **PaintDotNET Glow (Background).fxc** — Direct3D 11 compiled
- **PaintDotNET Glow (Background).fxao** — OpenGL ES (Android) source code
- **PaintDotNET Glow (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*