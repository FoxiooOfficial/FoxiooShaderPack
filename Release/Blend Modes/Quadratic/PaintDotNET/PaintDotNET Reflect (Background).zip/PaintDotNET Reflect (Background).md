## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **PaintDotNET Reflect (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **PaintDotNET Reflect (Background).xml** — Info & Integration
- **PaintDotNET Reflect (Background).fx** — Direct3D 9 source code
- **PaintDotNET Reflect (Background).hlsl** — Direct3D 11 source code
- **PaintDotNET Reflect (Background).fxc** — Direct3D 11 compiled
- **PaintDotNET Reflect (Background).fxao** — OpenGL ES (Android) source code
- **PaintDotNET Reflect (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*