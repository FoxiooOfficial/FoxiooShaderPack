## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Helow (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Helow (Background).xml** — Info & Integration
- **Krita Helow (Background).fx** — Direct3D 9 source code
- **Krita Helow (Background).hlsl** — Direct3D 11 source code
- **Krita Helow (Background).fxc** — Direct3D 11 compiled
- **Krita Helow (Background).fxao** — OpenGL ES (Android) source code
- **Krita Helow (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*