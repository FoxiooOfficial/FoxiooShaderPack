## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Heat-Glow (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Heat-Glow (Background).xml** — Info & Integration
- **Krita Heat-Glow (Background).fx** — Direct3D 9 source code
- **Krita Heat-Glow (Background).hlsl** — Direct3D 11 source code
- **Krita Heat-Glow (Background).fxc** — Direct3D 11 compiled
- **Krita Heat-Glow (Background).fxao** — OpenGL ES (Android) source code
- **Krita Heat-Glow (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*