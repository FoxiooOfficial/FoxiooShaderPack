## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Glow-Heat (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Glow-Heat (Background).xml** — Info & Integration
- **Krita Glow-Heat (Background).fx** — Direct3D 9 source code
- **Krita Glow-Heat (Background).hlsl** — Direct3D 11 source code
- **Krita Glow-Heat (Background).fxc** — Direct3D 11 compiled
- **Krita Glow-Heat (Background).fxao** — OpenGL ES (Android) source code
- **Krita Glow-Heat (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*