## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Gleat (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Gleat (Background).xml** — Info & Integration
- **Krita Gleat (Background).fx** — Direct3D 9 source code
- **Krita Gleat (Background).hlsl** — Direct3D 11 source code
- **Krita Gleat (Background).fxc** — Direct3D 11 compiled
- **Krita Gleat (Background).fxao** — OpenGL ES (Android) source code
- **Krita Gleat (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*