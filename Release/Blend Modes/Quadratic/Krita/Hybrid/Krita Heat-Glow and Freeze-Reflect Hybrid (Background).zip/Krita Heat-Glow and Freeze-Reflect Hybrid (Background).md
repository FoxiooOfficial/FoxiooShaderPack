## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Heat-Glow and Freeze-Reflect Hybrid (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Heat-Glow and Freeze-Reflect Hybrid (Background).xml** — Info & Integration
- **Krita Heat-Glow and Freeze-Reflect Hybrid (Background).fx** — Direct3D 9 source code
- **Krita Heat-Glow and Freeze-Reflect Hybrid (Background).hlsl** — Direct3D 11 source code
- **Krita Heat-Glow and Freeze-Reflect Hybrid (Background).fxc** — Direct3D 11 compiled
- **Krita Heat-Glow and Freeze-Reflect Hybrid (Background).fxao** — OpenGL ES (Android) source code
- **Krita Heat-Glow and Freeze-Reflect Hybrid (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*