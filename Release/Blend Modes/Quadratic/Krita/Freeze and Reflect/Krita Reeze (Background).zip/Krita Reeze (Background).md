## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Reeze (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Reeze (Background).xml** — Info & Integration
- **Krita Reeze (Background).fx** — Direct3D 9 source code
- **Krita Reeze (Background).hlsl** — Direct3D 11 source code
- **Krita Reeze (Background).fxc** — Direct3D 11 compiled
- **Krita Reeze (Background).fxao** — OpenGL ES (Android) source code
- **Krita Reeze (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*