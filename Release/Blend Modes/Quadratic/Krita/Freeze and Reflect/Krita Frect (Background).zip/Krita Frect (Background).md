## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Frect (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Frect (Background).xml** — Info & Integration
- **Krita Frect (Background).fx** — Direct3D 9 source code
- **Krita Frect (Background).hlsl** — Direct3D 11 source code
- **Krita Frect (Background).fxc** — Direct3D 11 compiled
- **Krita Frect (Background).fxao** — OpenGL ES (Android) source code
- **Krita Frect (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*