## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Freeze-Reflect (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Freeze-Reflect (Background).xml** — Info & Integration
- **Krita Freeze-Reflect (Background).fx** — Direct3D 9 source code
- **Krita Freeze-Reflect (Background).hlsl** — Direct3D 11 source code
- **Krita Freeze-Reflect (Background).fxc** — Direct3D 11 compiled
- **Krita Freeze-Reflect (Background).fxao** — OpenGL ES (Android) source code
- **Krita Freeze-Reflect (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*