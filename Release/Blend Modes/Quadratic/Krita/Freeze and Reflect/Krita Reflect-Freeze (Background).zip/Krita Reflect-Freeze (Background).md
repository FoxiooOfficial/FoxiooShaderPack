## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Reflect-Freeze (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Reflect-Freeze (Background).xml** — Info & Integration
- **Krita Reflect-Freeze (Background).fx** — Direct3D 9 source code
- **Krita Reflect-Freeze (Background).hlsl** — Direct3D 11 source code
- **Krita Reflect-Freeze (Background).fxc** — Direct3D 11 compiled
- **Krita Reflect-Freeze (Background).fxao** — OpenGL ES (Android) source code
- **Krita Reflect-Freeze (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*