## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Freeze (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Freeze (Background).xml** — Info & Integration
- **Krita Freeze (Background).fx** — Direct3D 9 source code
- **Krita Freeze (Background).hlsl** — Direct3D 11 source code
- **Krita Freeze (Background).fxc** — Direct3D 11 compiled
- **Krita Freeze (Background).fxao** — OpenGL ES (Android) source code
- **Krita Freeze (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*