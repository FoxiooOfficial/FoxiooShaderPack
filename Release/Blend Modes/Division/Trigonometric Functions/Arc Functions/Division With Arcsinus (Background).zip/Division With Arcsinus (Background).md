## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Division With Arcsinus (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Division With Arcsinus (Background).xml** — Info & Integration
- **Division With Arcsinus (Background).fx** — Direct3D 9 source code
- **Division With Arcsinus (Background).hlsl** — Direct3D 11 source code
- **Division With Arcsinus (Background).fxc** — Direct3D 11 compiled
- **Division With Arcsinus (Background).fxao** — OpenGL ES (Android) source code
- **Division With Arcsinus (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*