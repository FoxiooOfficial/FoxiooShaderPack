## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Division With Arccosinus (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Division With Arccosinus (Background).xml** — Info & Integration
- **Division With Arccosinus (Background).fx** — Direct3D 9 source code
- **Division With Arccosinus (Background).hlsl** — Direct3D 11 source code
- **Division With Arccosinus (Background).fxc** — Direct3D 11 compiled
- **Division With Arccosinus (Background).fxao** — OpenGL ES (Android) source code
- **Division With Arccosinus (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*