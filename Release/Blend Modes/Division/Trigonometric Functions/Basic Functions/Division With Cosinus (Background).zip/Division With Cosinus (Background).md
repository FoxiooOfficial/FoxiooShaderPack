## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Division With Cosinus (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Division With Cosinus (Background).xml** — Info & Integration
- **Division With Cosinus (Background).fx** — Direct3D 9 source code
- **Division With Cosinus (Background).hlsl** — Direct3D 11 source code
- **Division With Cosinus (Background).fxc** — Direct3D 11 compiled
- **Division With Cosinus (Background).fxao** — OpenGL ES (Android) source code
- **Division With Cosinus (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*