## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Division With Secant (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Division With Secant (Background).xml** — Info & Integration
- **Division With Secant (Background).fx** — Direct3D 9 source code
- **Division With Secant (Background).hlsl** — Direct3D 11 source code
- **Division With Secant (Background).fxc** — Direct3D 11 compiled
- **Division With Secant (Background).fxao** — OpenGL ES (Android) source code
- **Division With Secant (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*