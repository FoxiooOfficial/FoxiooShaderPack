## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Division (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Division (Background).xml** — Info & Integration
- **Division (Background).fx** — Direct3D 9 source code
- **Division (Background).hlsl** — Direct3D 11 source code
- **Division (Background).fxc** — Direct3D 11 compiled
- **Division (Background).fxao** — OpenGL ES (Android) source code
- **Division (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*