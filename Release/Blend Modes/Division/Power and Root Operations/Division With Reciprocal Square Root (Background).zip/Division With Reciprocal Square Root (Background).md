## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Division With Reciprocal Square Root (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Division With Reciprocal Square Root (Background).xml** — Info & Integration
- **Division With Reciprocal Square Root (Background).fx** — Direct3D 9 source code
- **Division With Reciprocal Square Root (Background).hlsl** — Direct3D 11 source code
- **Division With Reciprocal Square Root (Background).fxc** — Direct3D 11 compiled
- **Division With Reciprocal Square Root (Background).fxao** — OpenGL ES (Android) source code
- **Division With Reciprocal Square Root (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*