## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Lighter Color (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Lighter Color (Background).xml** — Info & Integration
- **Photoshop Lighter Color (Background).fx** — Direct3D 9 source code
- **Photoshop Lighter Color (Background).hlsl** — Direct3D 11 source code
- **Photoshop Lighter Color (Background).fxc** — Direct3D 11 compiled
- **Photoshop Lighter Color (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Lighter Color (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*