## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Screen (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Screen (Background).xml** — Info & Integration
- **Photoshop Screen (Background).fx** — Direct3D 9 source code
- **Photoshop Screen (Background).hlsl** — Direct3D 11 source code
- **Photoshop Screen (Background).fxc** — Direct3D 11 compiled
- **Photoshop Screen (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Screen (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*