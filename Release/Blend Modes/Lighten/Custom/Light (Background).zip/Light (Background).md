## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Light (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Light (Background).xml** — Info & Integration
- **Light (Background).fx** — Direct3D 9 source code
- **Light (Background).hlsl** — Direct3D 11 source code
- **Light (Background).fxc** — Direct3D 11 compiled
- **Light (Background).fxao** — OpenGL ES (Android) source code
- **Light (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*