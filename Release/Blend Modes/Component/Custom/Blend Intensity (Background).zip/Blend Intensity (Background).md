## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Blend Intensity (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Blend Intensity (Background).xml** — Info & Integration
- **Blend Intensity (Background).fx** — Direct3D 9 source code
- **Blend Intensity (Background).hlsl** — Direct3D 11 source code
- **Blend Intensity (Background).fxc** — Direct3D 11 compiled
- **Blend Intensity (Background).fxao** — OpenGL ES (Android) source code
- **Blend Intensity (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*