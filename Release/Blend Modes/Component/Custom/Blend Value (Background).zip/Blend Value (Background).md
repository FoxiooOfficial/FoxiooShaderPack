## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Blend Value (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Blend Value (Background).xml** — Info & Integration
- **Blend Value (Background).fx** — Direct3D 9 source code
- **Blend Value (Background).hlsl** — Direct3D 11 source code
- **Blend Value (Background).fxc** — Direct3D 11 compiled
- **Blend Value (Background).fxao** — OpenGL ES (Android) source code
- **Blend Value (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*