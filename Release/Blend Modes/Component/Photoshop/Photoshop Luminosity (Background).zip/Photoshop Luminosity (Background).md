## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Luminosity (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Luminosity (Background).xml** — Info & Integration
- **Photoshop Luminosity (Background).fx** — Direct3D 9 source code
- **Photoshop Luminosity (Background).hlsl** — Direct3D 11 source code
- **Photoshop Luminosity (Background).fxc** — Direct3D 11 compiled
- **Photoshop Luminosity (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Luminosity (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*