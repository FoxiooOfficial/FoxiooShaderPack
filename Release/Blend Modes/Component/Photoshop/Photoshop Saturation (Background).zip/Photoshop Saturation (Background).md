## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Saturation (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Saturation (Background).xml** — Info & Integration
- **Photoshop Saturation (Background).fx** — Direct3D 9 source code
- **Photoshop Saturation (Background).hlsl** — Direct3D 11 source code
- **Photoshop Saturation (Background).fxc** — Direct3D 11 compiled
- **Photoshop Saturation (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Saturation (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*