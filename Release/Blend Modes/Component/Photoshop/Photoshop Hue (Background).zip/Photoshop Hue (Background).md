## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Hue (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Hue (Background).xml** — Info & Integration
- **Photoshop Hue (Background).fx** — Direct3D 9 source code
- **Photoshop Hue (Background).hlsl** — Direct3D 11 source code
- **Photoshop Hue (Background).fxc** — Direct3D 11 compiled
- **Photoshop Hue (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Hue (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*