## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Color (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Color (Background).xml** — Info & Integration
- **Photoshop Color (Background).fx** — Direct3D 9 source code
- **Photoshop Color (Background).hlsl** — Direct3D 11 source code
- **Photoshop Color (Background).fxc** — Direct3D 11 compiled
- **Photoshop Color (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Color (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*