## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Subtraction (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Subtraction (Background).xml** — Info & Integration
- **Subtraction (Background).fx** — Direct3D 9 source code
- **Subtraction (Background).hlsl** — Direct3D 11 source code
- **Subtraction (Background).fxc** — Direct3D 11 compiled
- **Subtraction (Background).fxao** — OpenGL ES (Android) source code
- **Subtraction (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*