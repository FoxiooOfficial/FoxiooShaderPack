## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Subtraction With Power (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Subtraction With Power (Background).xml** — Info & Integration
- **Subtraction With Power (Background).fx** — Direct3D 9 source code
- **Subtraction With Power (Background).hlsl** — Direct3D 11 source code
- **Subtraction With Power (Background).fxc** — Direct3D 11 compiled
- **Subtraction With Power (Background).fxao** — OpenGL ES (Android) source code
- **Subtraction With Power (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*