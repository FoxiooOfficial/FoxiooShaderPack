## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Subtraction With Cosecant (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Subtraction With Cosecant (Background).xml** — Info & Integration
- **Subtraction With Cosecant (Background).fx** — Direct3D 9 source code
- **Subtraction With Cosecant (Background).hlsl** — Direct3D 11 source code
- **Subtraction With Cosecant (Background).fxc** — Direct3D 11 compiled
- **Subtraction With Cosecant (Background).fxao** — OpenGL ES (Android) source code
- **Subtraction With Cosecant (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*