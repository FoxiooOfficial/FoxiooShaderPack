## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Subtraction With Cosinus (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Subtraction With Cosinus (Background).xml** — Info & Integration
- **Subtraction With Cosinus (Background).fx** — Direct3D 9 source code
- **Subtraction With Cosinus (Background).hlsl** — Direct3D 11 source code
- **Subtraction With Cosinus (Background).fxc** — Direct3D 11 compiled
- **Subtraction With Cosinus (Background).fxao** — OpenGL ES (Android) source code
- **Subtraction With Cosinus (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*