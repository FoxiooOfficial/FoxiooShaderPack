## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Subtraction With Tangent (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Subtraction With Tangent (Background).xml** — Info & Integration
- **Subtraction With Tangent (Background).fx** — Direct3D 9 source code
- **Subtraction With Tangent (Background).hlsl** — Direct3D 11 source code
- **Subtraction With Tangent (Background).fxc** — Direct3D 11 compiled
- **Subtraction With Tangent (Background).fxao** — OpenGL ES (Android) source code
- **Subtraction With Tangent (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*