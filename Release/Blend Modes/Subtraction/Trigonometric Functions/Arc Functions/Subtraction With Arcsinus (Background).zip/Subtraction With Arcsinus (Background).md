## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Subtraction With Arcsinus (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Subtraction With Arcsinus (Background).xml** — Info & Integration
- **Subtraction With Arcsinus (Background).fx** — Direct3D 9 source code
- **Subtraction With Arcsinus (Background).hlsl** — Direct3D 11 source code
- **Subtraction With Arcsinus (Background).fxc** — Direct3D 11 compiled
- **Subtraction With Arcsinus (Background).fxao** — OpenGL ES (Android) source code
- **Subtraction With Arcsinus (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*