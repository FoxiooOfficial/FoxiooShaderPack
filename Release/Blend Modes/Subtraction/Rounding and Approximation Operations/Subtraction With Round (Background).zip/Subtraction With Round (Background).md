## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Subtraction With Round (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Subtraction With Round (Background).xml** — Info & Integration
- **Subtraction With Round (Background).fx** — Direct3D 9 source code
- **Subtraction With Round (Background).hlsl** — Direct3D 11 source code
- **Subtraction With Round (Background).fxc** — Direct3D 11 compiled
- **Subtraction With Round (Background).fxao** — OpenGL ES (Android) source code
- **Subtraction With Round (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*