## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Dissolve (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Dissolve (Texture).xml** — Info & Integration
- **Photoshop Dissolve (Texture).fx** — Direct3D 9 source code
- **Photoshop Dissolve (Texture).hlsl** — Direct3D 11 source code
- **Photoshop Dissolve (Texture).fxc** — Direct3D 11 compiled
- **Photoshop Dissolve (Texture).fxao** — OpenGL ES (Android) source code
- **Photoshop Dissolve (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*