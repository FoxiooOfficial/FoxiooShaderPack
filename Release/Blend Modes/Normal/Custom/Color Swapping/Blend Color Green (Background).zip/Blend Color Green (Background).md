## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Blend Color Green (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Blend Color Green (Background).xml** — Info & Integration
- **Blend Color Green (Background).fx** — Direct3D 9 source code
- **Blend Color Green (Background).hlsl** — Direct3D 11 source code
- **Blend Color Green (Background).fxc** — Direct3D 11 compiled
- **Blend Color Green (Background).fxao** — OpenGL ES (Android) source code
- **Blend Color Green (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*