## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Blend Color Cyan (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Blend Color Cyan (Background).xml** — Info & Integration
- **Blend Color Cyan (Background).fx** — Direct3D 9 source code
- **Blend Color Cyan (Background).hlsl** — Direct3D 11 source code
- **Blend Color Cyan (Background).fxc** — Direct3D 11 compiled
- **Blend Color Cyan (Background).fxao** — OpenGL ES (Android) source code
- **Blend Color Cyan (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*