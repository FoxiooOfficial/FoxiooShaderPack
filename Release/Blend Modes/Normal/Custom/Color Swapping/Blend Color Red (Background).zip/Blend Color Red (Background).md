## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Blend Color Red (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Blend Color Red (Background).xml** — Info & Integration
- **Blend Color Red (Background).fx** — Direct3D 9 source code
- **Blend Color Red (Background).hlsl** — Direct3D 11 source code
- **Blend Color Red (Background).fxc** — Direct3D 11 compiled
- **Blend Color Red (Background).fxao** — OpenGL ES (Android) source code
- **Blend Color Red (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*