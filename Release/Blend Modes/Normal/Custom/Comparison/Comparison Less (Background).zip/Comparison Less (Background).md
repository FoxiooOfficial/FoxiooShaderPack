## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Comparison Less (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Comparison Less (Background).xml** — Info & Integration
- **Comparison Less (Background).fx** — Direct3D 9 source code
- **Comparison Less (Background).hlsl** — Direct3D 11 source code
- **Comparison Less (Background).fxc** — Direct3D 11 compiled
- **Comparison Less (Background).fxao** — OpenGL ES (Android) source code
- **Comparison Less (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*