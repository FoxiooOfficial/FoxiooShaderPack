## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Comparison Equal (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Comparison Equal (Background).xml** — Info & Integration
- **Comparison Equal (Background).fx** — Direct3D 9 source code
- **Comparison Equal (Background).hlsl** — Direct3D 11 source code
- **Comparison Equal (Background).fxc** — Direct3D 11 compiled
- **Comparison Equal (Background).fxao** — OpenGL ES (Android) source code
- **Comparison Equal (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*