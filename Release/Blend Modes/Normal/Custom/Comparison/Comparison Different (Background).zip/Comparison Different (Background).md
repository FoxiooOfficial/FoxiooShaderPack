## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Comparison Different (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Comparison Different (Background).xml** — Info & Integration
- **Comparison Different (Background).fx** — Direct3D 9 source code
- **Comparison Different (Background).hlsl** — Direct3D 11 source code
- **Comparison Different (Background).fxc** — Direct3D 11 compiled
- **Comparison Different (Background).fxao** — OpenGL ES (Android) source code
- **Comparison Different (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*