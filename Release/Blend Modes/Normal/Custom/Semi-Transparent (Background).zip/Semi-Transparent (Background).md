## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Semi-Transparent (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Semi-Transparent (Background).xml** — Info & Integration
- **Semi-Transparent (Background).fx** — Direct3D 9 source code
- **Semi-Transparent (Background).hlsl** — Direct3D 11 source code
- **Semi-Transparent (Background).fxc** — Direct3D 11 compiled
- **Semi-Transparent (Background).fxao** — OpenGL ES (Android) source code
- **Semi-Transparent (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*