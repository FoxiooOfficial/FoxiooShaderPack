## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Blend Average (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Blend Average (Background).xml** — Info & Integration
- **Blend Average (Background).fx** — Direct3D 9 source code
- **Blend Average (Background).hlsl** — Direct3D 11 source code
- **Blend Average (Background).fxc** — Direct3D 11 compiled
- **Blend Average (Background).fxao** — OpenGL ES (Android) source code
- **Blend Average (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*