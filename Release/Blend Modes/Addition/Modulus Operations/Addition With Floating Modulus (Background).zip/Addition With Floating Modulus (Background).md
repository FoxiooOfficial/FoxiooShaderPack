## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Addition With Floating Modulus (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Addition With Floating Modulus (Background).xml** — Info & Integration
- **Addition With Floating Modulus (Background).fx** — Direct3D 9 source code
- **Addition With Floating Modulus (Background).hlsl** — Direct3D 11 source code
- **Addition With Floating Modulus (Background).fxc** — Direct3D 11 compiled
- **Addition With Floating Modulus (Background).fxao** — OpenGL ES (Android) source code
- **Addition With Floating Modulus (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*