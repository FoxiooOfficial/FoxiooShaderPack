## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Addition (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Addition (Background).xml** — Info & Integration
- **Addition (Background).fx** — Direct3D 9 source code
- **Addition (Background).hlsl** — Direct3D 11 source code
- **Addition (Background).fxc** — Direct3D 11 compiled
- **Addition (Background).fxao** — OpenGL ES (Android) source code
- **Addition (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*