## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Addition With Hyperbolic Cotangent (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Addition With Hyperbolic Cotangent (Background).xml** — Info & Integration
- **Addition With Hyperbolic Cotangent (Background).fx** — Direct3D 9 source code
- **Addition With Hyperbolic Cotangent (Background).hlsl** — Direct3D 11 source code
- **Addition With Hyperbolic Cotangent (Background).fxc** — Direct3D 11 compiled
- **Addition With Hyperbolic Cotangent (Background).fxao** — OpenGL ES (Android) source code
- **Addition With Hyperbolic Cotangent (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*