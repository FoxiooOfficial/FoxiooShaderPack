## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Addition With Hyperbolic Cosecant (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Addition With Hyperbolic Cosecant (Background).xml** — Info & Integration
- **Addition With Hyperbolic Cosecant (Background).fx** — Direct3D 9 source code
- **Addition With Hyperbolic Cosecant (Background).hlsl** — Direct3D 11 source code
- **Addition With Hyperbolic Cosecant (Background).fxc** — Direct3D 11 compiled
- **Addition With Hyperbolic Cosecant (Background).fxao** — OpenGL ES (Android) source code
- **Addition With Hyperbolic Cosecant (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*