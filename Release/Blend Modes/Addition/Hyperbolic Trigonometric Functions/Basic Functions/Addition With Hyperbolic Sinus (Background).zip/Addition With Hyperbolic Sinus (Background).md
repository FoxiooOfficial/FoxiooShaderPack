## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Addition With Hyperbolic Sinus (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Addition With Hyperbolic Sinus (Background).xml** — Info & Integration
- **Addition With Hyperbolic Sinus (Background).fx** — Direct3D 9 source code
- **Addition With Hyperbolic Sinus (Background).hlsl** — Direct3D 11 source code
- **Addition With Hyperbolic Sinus (Background).fxc** — Direct3D 11 compiled
- **Addition With Hyperbolic Sinus (Background).fxao** — OpenGL ES (Android) source code
- **Addition With Hyperbolic Sinus (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*