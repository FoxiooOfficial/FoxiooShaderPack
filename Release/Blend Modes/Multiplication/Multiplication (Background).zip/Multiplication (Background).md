## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Multiplication (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Multiplication (Background).xml** — Info & Integration
- **Multiplication (Background).fx** — Direct3D 9 source code
- **Multiplication (Background).hlsl** — Direct3D 11 source code
- **Multiplication (Background).fxc** — Direct3D 11 compiled
- **Multiplication (Background).fxao** — OpenGL ES (Android) source code
- **Multiplication (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*