## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Multiplication With Hyperbolic Tangent (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Multiplication With Hyperbolic Tangent (Background).xml** — Info & Integration
- **Multiplication With Hyperbolic Tangent (Background).fx** — Direct3D 9 source code
- **Multiplication With Hyperbolic Tangent (Background).hlsl** — Direct3D 11 source code
- **Multiplication With Hyperbolic Tangent (Background).fxc** — Direct3D 11 compiled
- **Multiplication With Hyperbolic Tangent (Background).fxao** — OpenGL ES (Android) source code
- **Multiplication With Hyperbolic Tangent (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*