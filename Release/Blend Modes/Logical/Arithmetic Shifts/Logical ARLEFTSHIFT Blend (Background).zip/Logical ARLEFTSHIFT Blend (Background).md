## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical ARLEFTSHIFT Blend (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical ARLEFTSHIFT Blend (Background).xml** — Info & Integration
- **Logical ARLEFTSHIFT Blend (Background).fx** — Direct3D 9 source code
- **Logical ARLEFTSHIFT Blend (Background).hlsl** — Direct3D 11 source code
- **Logical ARLEFTSHIFT Blend (Background).fxc** — Direct3D 11 compiled
- **Logical ARLEFTSHIFT Blend (Background).fxao** — OpenGL ES (Android) source code
- **Logical ARLEFTSHIFT Blend (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*