## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical ARLEFTSHIFT Base (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical ARLEFTSHIFT Base (Background).xml** — Info & Integration
- **Logical ARLEFTSHIFT Base (Background).fx** — Direct3D 9 source code
- **Logical ARLEFTSHIFT Base (Background).hlsl** — Direct3D 11 source code
- **Logical ARLEFTSHIFT Base (Background).fxc** — Direct3D 11 compiled
- **Logical ARLEFTSHIFT Base (Background).fxao** — OpenGL ES (Android) source code
- **Logical ARLEFTSHIFT Base (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*