## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical XOR (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical XOR (Background).xml** — Info & Integration
- **Logical XOR (Background).fx** — Direct3D 9 source code
- **Logical XOR (Background).hlsl** — Direct3D 11 source code
- **Logical XOR (Background).fxc** — Direct3D 11 compiled
- **Logical XOR (Background).fxao** — OpenGL ES (Android) source code
- **Logical XOR (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*