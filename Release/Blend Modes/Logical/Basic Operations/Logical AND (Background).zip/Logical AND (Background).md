## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical AND (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical AND (Background).xml** — Info & Integration
- **Logical AND (Background).fx** — Direct3D 9 source code
- **Logical AND (Background).hlsl** — Direct3D 11 source code
- **Logical AND (Background).fxc** — Direct3D 11 compiled
- **Logical AND (Background).fxao** — OpenGL ES (Android) source code
- **Logical AND (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*