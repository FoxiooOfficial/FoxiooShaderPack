## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical OR (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical OR (Background).xml** — Info & Integration
- **Logical OR (Background).fx** — Direct3D 9 source code
- **Logical OR (Background).hlsl** — Direct3D 11 source code
- **Logical OR (Background).fxc** — Direct3D 11 compiled
- **Logical OR (Background).fxao** — OpenGL ES (Android) source code
- **Logical OR (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*