## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical XIMPLY (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical XIMPLY (Background).xml** — Info & Integration
- **Logical XIMPLY (Background).fx** — Direct3D 9 source code
- **Logical XIMPLY (Background).hlsl** — Direct3D 11 source code
- **Logical XIMPLY (Background).fxc** — Direct3D 11 compiled
- **Logical XIMPLY (Background).fxao** — OpenGL ES (Android) source code
- **Logical XIMPLY (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*