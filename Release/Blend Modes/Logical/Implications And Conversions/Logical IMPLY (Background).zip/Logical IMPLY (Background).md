## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical IMPLY (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical IMPLY (Background).xml** — Info & Integration
- **Logical IMPLY (Background).fx** — Direct3D 9 source code
- **Logical IMPLY (Background).hlsl** — Direct3D 11 source code
- **Logical IMPLY (Background).fxc** — Direct3D 11 compiled
- **Logical IMPLY (Background).fxao** — OpenGL ES (Android) source code
- **Logical IMPLY (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*