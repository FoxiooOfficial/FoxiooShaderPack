## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical XNIMPLY (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical XNIMPLY (Background).xml** — Info & Integration
- **Logical XNIMPLY (Background).fx** — Direct3D 9 source code
- **Logical XNIMPLY (Background).hlsl** — Direct3D 11 source code
- **Logical XNIMPLY (Background).fxc** — Direct3D 11 compiled
- **Logical XNIMPLY (Background).fxao** — OpenGL ES (Android) source code
- **Logical XNIMPLY (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*