## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical NIMPLY (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical NIMPLY (Background).xml** — Info & Integration
- **Logical NIMPLY (Background).fx** — Direct3D 9 source code
- **Logical NIMPLY (Background).hlsl** — Direct3D 11 source code
- **Logical NIMPLY (Background).fxc** — Direct3D 11 compiled
- **Logical NIMPLY (Background).fxao** — OpenGL ES (Android) source code
- **Logical NIMPLY (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*