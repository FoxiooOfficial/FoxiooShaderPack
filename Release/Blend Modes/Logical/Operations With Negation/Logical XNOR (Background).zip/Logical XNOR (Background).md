## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical XNOR (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical XNOR (Background).xml** — Info & Integration
- **Logical XNOR (Background).fx** — Direct3D 9 source code
- **Logical XNOR (Background).hlsl** — Direct3D 11 source code
- **Logical XNOR (Background).fxc** — Direct3D 11 compiled
- **Logical XNOR (Background).fxao** — OpenGL ES (Android) source code
- **Logical XNOR (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*