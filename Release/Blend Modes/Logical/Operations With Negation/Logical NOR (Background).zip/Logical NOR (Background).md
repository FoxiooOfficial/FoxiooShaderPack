## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical NOR (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical NOR (Background).xml** — Info & Integration
- **Logical NOR (Background).fx** — Direct3D 9 source code
- **Logical NOR (Background).hlsl** — Direct3D 11 source code
- **Logical NOR (Background).fxc** — Direct3D 11 compiled
- **Logical NOR (Background).fxao** — OpenGL ES (Android) source code
- **Logical NOR (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*