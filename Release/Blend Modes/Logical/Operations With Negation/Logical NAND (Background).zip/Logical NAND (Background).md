## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical NAND (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical NAND (Background).xml** — Info & Integration
- **Logical NAND (Background).fx** — Direct3D 9 source code
- **Logical NAND (Background).hlsl** — Direct3D 11 source code
- **Logical NAND (Background).fxc** — Direct3D 11 compiled
- **Logical NAND (Background).fxao** — OpenGL ES (Android) source code
- **Logical NAND (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*