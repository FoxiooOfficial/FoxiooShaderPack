## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical LEFTSHIFT Blend (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical LEFTSHIFT Blend (Background).xml** — Info & Integration
- **Logical LEFTSHIFT Blend (Background).fx** — Direct3D 9 source code
- **Logical LEFTSHIFT Blend (Background).hlsl** — Direct3D 11 source code
- **Logical LEFTSHIFT Blend (Background).fxc** — Direct3D 11 compiled
- **Logical LEFTSHIFT Blend (Background).fxao** — OpenGL ES (Android) source code
- **Logical LEFTSHIFT Blend (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*