## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical ROTATELEFT Blend (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical ROTATELEFT Blend (Background).xml** — Info & Integration
- **Logical ROTATELEFT Blend (Background).fx** — Direct3D 9 source code
- **Logical ROTATELEFT Blend (Background).hlsl** — Direct3D 11 source code
- **Logical ROTATELEFT Blend (Background).fxc** — Direct3D 11 compiled
- **Logical ROTATELEFT Blend (Background).fxao** — OpenGL ES (Android) source code
- **Logical ROTATELEFT Blend (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*