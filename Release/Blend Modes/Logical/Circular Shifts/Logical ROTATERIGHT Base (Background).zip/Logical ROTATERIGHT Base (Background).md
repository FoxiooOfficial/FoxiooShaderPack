## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Logical ROTATERIGHT Base (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Logical ROTATERIGHT Base (Background).xml** — Info & Integration
- **Logical ROTATERIGHT Base (Background).fx** — Direct3D 9 source code
- **Logical ROTATERIGHT Base (Background).hlsl** — Direct3D 11 source code
- **Logical ROTATERIGHT Base (Background).fxc** — Direct3D 11 compiled
- **Logical ROTATERIGHT Base (Background).fxao** — OpenGL ES (Android) source code
- **Logical ROTATERIGHT Base (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*