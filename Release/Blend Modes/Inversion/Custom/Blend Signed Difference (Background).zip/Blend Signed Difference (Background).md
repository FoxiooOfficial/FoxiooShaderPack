## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Blend Signed Difference (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Blend Signed Difference (Background).xml** — Info & Integration
- **Blend Signed Difference (Background).fx** — Direct3D 9 source code
- **Blend Signed Difference (Background).hlsl** — Direct3D 11 source code
- **Blend Signed Difference (Background).fxc** — Direct3D 11 compiled
- **Blend Signed Difference (Background).fxao** — OpenGL ES (Android) source code
- **Blend Signed Difference (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*