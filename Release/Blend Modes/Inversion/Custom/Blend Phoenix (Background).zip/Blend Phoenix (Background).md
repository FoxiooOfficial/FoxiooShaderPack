## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Blend Phoenix (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Blend Phoenix (Background).xml** — Info & Integration
- **Blend Phoenix (Background).fx** — Direct3D 9 source code
- **Blend Phoenix (Background).hlsl** — Direct3D 11 source code
- **Blend Phoenix (Background).fxc** — Direct3D 11 compiled
- **Blend Phoenix (Background).fxao** — OpenGL ES (Android) source code
- **Blend Phoenix (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*