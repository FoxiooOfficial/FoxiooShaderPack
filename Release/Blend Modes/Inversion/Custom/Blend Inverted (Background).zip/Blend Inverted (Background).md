## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Blend Inverted (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Blend Inverted (Background).xml** — Info & Integration
- **Blend Inverted (Background).fx** — Direct3D 9 source code
- **Blend Inverted (Background).hlsl** — Direct3D 11 source code
- **Blend Inverted (Background).fxc** — Direct3D 11 compiled
- **Blend Inverted (Background).fxao** — OpenGL ES (Android) source code
- **Blend Inverted (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*