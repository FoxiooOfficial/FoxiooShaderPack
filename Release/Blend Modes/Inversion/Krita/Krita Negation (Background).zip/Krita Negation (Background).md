## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Negation (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Negation (Background).xml** — Info & Integration
- **Krita Negation (Background).fx** — Direct3D 9 source code
- **Krita Negation (Background).hlsl** — Direct3D 11 source code
- **Krita Negation (Background).fxc** — Direct3D 11 compiled
- **Krita Negation (Background).fxao** — OpenGL ES (Android) source code
- **Krita Negation (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*