## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Additive Subtractive (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Additive Subtractive (Background).xml** — Info & Integration
- **Krita Additive Subtractive (Background).fx** — Direct3D 9 source code
- **Krita Additive Subtractive (Background).hlsl** — Direct3D 11 source code
- **Krita Additive Subtractive (Background).fxc** — Direct3D 11 compiled
- **Krita Additive Subtractive (Background).fxao** — OpenGL ES (Android) source code
- **Krita Additive Subtractive (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*