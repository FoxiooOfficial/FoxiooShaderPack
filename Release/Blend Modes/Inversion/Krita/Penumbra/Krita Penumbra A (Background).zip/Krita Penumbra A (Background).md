## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Penumbra A (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Penumbra A (Background).xml** — Info & Integration
- **Krita Penumbra A (Background).fx** — Direct3D 9 source code
- **Krita Penumbra A (Background).hlsl** — Direct3D 11 source code
- **Krita Penumbra A (Background).fxc** — Direct3D 11 compiled
- **Krita Penumbra A (Background).fxao** — OpenGL ES (Android) source code
- **Krita Penumbra A (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*