## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Penumbra B (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Penumbra B (Background).xml** — Info & Integration
- **Krita Penumbra B (Background).fx** — Direct3D 9 source code
- **Krita Penumbra B (Background).hlsl** — Direct3D 11 source code
- **Krita Penumbra B (Background).fxc** — Direct3D 11 compiled
- **Krita Penumbra B (Background).fxao** — OpenGL ES (Android) source code
- **Krita Penumbra B (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*