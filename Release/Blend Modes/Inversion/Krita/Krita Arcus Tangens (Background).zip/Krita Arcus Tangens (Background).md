## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Arcus Tangens (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Arcus Tangens (Background).xml** — Info & Integration
- **Krita Arcus Tangens (Background).fx** — Direct3D 9 source code
- **Krita Arcus Tangens (Background).hlsl** — Direct3D 11 source code
- **Krita Arcus Tangens (Background).fxc** — Direct3D 11 compiled
- **Krita Arcus Tangens (Background).fxao** — OpenGL ES (Android) source code
- **Krita Arcus Tangens (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*