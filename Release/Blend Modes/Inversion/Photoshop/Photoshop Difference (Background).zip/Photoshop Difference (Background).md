## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Difference (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Difference (Background).xml** — Info & Integration
- **Photoshop Difference (Background).fx** — Direct3D 9 source code
- **Photoshop Difference (Background).hlsl** — Direct3D 11 source code
- **Photoshop Difference (Background).fxc** — Direct3D 11 compiled
- **Photoshop Difference (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Difference (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*