## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Darker Color (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Darker Color (Background).xml** — Info & Integration
- **Photoshop Darker Color (Background).fx** — Direct3D 9 source code
- **Photoshop Darker Color (Background).hlsl** — Direct3D 11 source code
- **Photoshop Darker Color (Background).fxc** — Direct3D 11 compiled
- **Photoshop Darker Color (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Darker Color (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*