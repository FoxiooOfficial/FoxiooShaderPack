## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Darken (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Darken (Background).xml** — Info & Integration
- **Photoshop Darken (Background).fx** — Direct3D 9 source code
- **Photoshop Darken (Background).hlsl** — Direct3D 11 source code
- **Photoshop Darken (Background).fxc** — Direct3D 11 compiled
- **Photoshop Darken (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Darken (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*