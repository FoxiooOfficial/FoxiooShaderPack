## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Linear Burn (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Linear Burn (Background).xml** — Info & Integration
- **Photoshop Linear Burn (Background).fx** — Direct3D 9 source code
- **Photoshop Linear Burn (Background).hlsl** — Direct3D 11 source code
- **Photoshop Linear Burn (Background).fxc** — Direct3D 11 compiled
- **Photoshop Linear Burn (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Linear Burn (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*