## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Blend Stamp (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Blend Stamp (Background).xml** — Info & Integration
- **Blend Stamp (Background).fx** — Direct3D 9 source code
- **Blend Stamp (Background).hlsl** — Direct3D 11 source code
- **Blend Stamp (Background).fxc** — Direct3D 11 compiled
- **Blend Stamp (Background).fxao** — OpenGL ES (Android) source code
- **Blend Stamp (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*