## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **GIMP Grain Extract (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **GIMP Grain Extract (Background).xml** — Info & Integration
- **GIMP Grain Extract (Background).fx** — Direct3D 9 source code
- **GIMP Grain Extract (Background).hlsl** — Direct3D 11 source code
- **GIMP Grain Extract (Background).fxc** — Direct3D 11 compiled
- **GIMP Grain Extract (Background).fxao** — OpenGL ES (Android) source code
- **GIMP Grain Extract (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*