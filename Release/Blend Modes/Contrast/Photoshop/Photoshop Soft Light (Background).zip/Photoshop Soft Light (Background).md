## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Soft Light (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Soft Light (Background).xml** — Info & Integration
- **Photoshop Soft Light (Background).fx** — Direct3D 9 source code
- **Photoshop Soft Light (Background).hlsl** — Direct3D 11 source code
- **Photoshop Soft Light (Background).fxc** — Direct3D 11 compiled
- **Photoshop Soft Light (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Soft Light (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*