## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Hard Mix (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Hard Mix (Background).xml** — Info & Integration
- **Photoshop Hard Mix (Background).fx** — Direct3D 9 source code
- **Photoshop Hard Mix (Background).hlsl** — Direct3D 11 source code
- **Photoshop Hard Mix (Background).fxc** — Direct3D 11 compiled
- **Photoshop Hard Mix (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Hard Mix (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*