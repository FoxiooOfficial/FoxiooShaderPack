## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Overlay (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Overlay (Background).xml** — Info & Integration
- **Photoshop Overlay (Background).fx** — Direct3D 9 source code
- **Photoshop Overlay (Background).hlsl** — Direct3D 11 source code
- **Photoshop Overlay (Background).fxc** — Direct3D 11 compiled
- **Photoshop Overlay (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Overlay (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*