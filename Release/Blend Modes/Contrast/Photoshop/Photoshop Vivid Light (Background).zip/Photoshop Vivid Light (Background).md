## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Photoshop Vivid Light (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Photoshop Vivid Light (Background).xml** — Info & Integration
- **Photoshop Vivid Light (Background).fx** — Direct3D 9 source code
- **Photoshop Vivid Light (Background).hlsl** — Direct3D 11 source code
- **Photoshop Vivid Light (Background).fxc** — Direct3D 11 compiled
- **Photoshop Vivid Light (Background).fxao** — OpenGL ES (Android) source code
- **Photoshop Vivid Light (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*