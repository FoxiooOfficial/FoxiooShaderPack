## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Hard Mix Softer (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Hard Mix Softer (Background).xml** — Info & Integration
- **Krita Hard Mix Softer (Background).fx** — Direct3D 9 source code
- **Krita Hard Mix Softer (Background).hlsl** — Direct3D 11 source code
- **Krita Hard Mix Softer (Background).fxc** — Direct3D 11 compiled
- **Krita Hard Mix Softer (Background).fxao** — OpenGL ES (Android) source code
- **Krita Hard Mix Softer (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*