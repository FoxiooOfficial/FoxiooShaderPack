## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Krita Interpolation (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Krita Interpolation (Background).xml** — Info & Integration
- **Krita Interpolation (Background).fx** — Direct3D 9 source code
- **Krita Interpolation (Background).hlsl** — Direct3D 11 source code
- **Krita Interpolation (Background).fxc** — Direct3D 11 compiled
- **Krita Interpolation (Background).fxao** — OpenGL ES (Android) source code
- **Krita Interpolation (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*