## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Quad With Floor Reflection (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Quad With Floor Reflection (Background).xml** — Info & Integration
- **Quad With Floor Reflection (Background).fx** — Direct3D 9 source code
- **Quad With Floor Reflection (Background).hlsl** — Direct3D 11 source code
- **Quad With Floor Reflection (Background).fxc** — Direct3D 11 compiled
- **Quad With Floor Reflection (Background).fxao** — OpenGL ES (Android) source code
- **Quad With Floor Reflection (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*