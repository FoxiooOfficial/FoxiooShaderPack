## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **Unity Bloom (Background).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **Unity Bloom (Background).xml** — Info & Integration
- **Unity Bloom (Background).fx** — Direct3D 9 source code
- **Unity Bloom (Background).hlsl** — Direct3D 11 source code
- **Unity Bloom (Background).fxc** — Direct3D 11 compiled
- **Unity Bloom (Background).fxao** — OpenGL ES (Android) source code
- **Unity Bloom (Background).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*