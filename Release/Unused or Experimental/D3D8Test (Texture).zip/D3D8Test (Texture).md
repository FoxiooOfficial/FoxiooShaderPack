## Info
**Last Updated:** 2026-04-13 21:09  

## Shader files
- **D3D8Test (Texture).premultiplied.fxc** — Direct3D 11 compiled (Premultiplied*)
- **D3D8Test (Texture).xml** — Info & Integration
- **D3D8Test (Texture).fx** — Direct3D 9 and Direct3D 8 source code
- **D3D8Test (Texture).hlsl** — Direct3D 11 source code
- **D3D8Test (Texture).fxc** — Direct3D 11 compiled
- **D3D8Test (Texture).fxao** — OpenGL ES (Android) source code
- **D3D8Test (Texture).fxmo** — OpenGL ES (iOS and macOS) source code

*Sometimes a shader needs Premultiplied version to fix Alpha Channel handling in Premultiplied graphics.*